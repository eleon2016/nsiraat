<?php

class CentersController
{
    function __construct()
    {
        
    }
    
    public function getAllCenters( $level=null)
    {
        if( $level == 1)
            include '../../../model/Centers.class.php';
        else
            include '../../model/Centers.class.php';
            
        $centers = new CentersModel();
        $data = $centers->getAllCenters();
        return $data;
    }


}
