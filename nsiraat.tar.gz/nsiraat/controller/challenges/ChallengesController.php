<?php

class ChallengesController
{
    function __construct()
    {
        
    }
    
    public function ListAllChallenges()
    {
        include '../../../model/Challenges.class.php';
        $list_challenges = new Challenges();
        return $list_challenges->ListAllChallenges();
    }
}