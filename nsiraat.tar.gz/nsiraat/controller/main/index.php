<?php
session_start();

if( $_SESSION['SessionKey'] == '1db6d112c80273f1b76a45f6ecc76f7a' )
{
    include 'MainController.php';
    $main = new Main();
    $main->init();
}else{
    header('location:../../index.html');
}