<?php

class Main
{
    function __construct()
    {
        
    }
    
    public function init()
    {
        include '../../php/mTemplate.class.php';
        $view = new MountTemplate('basicTemplate',0,'html');
        
        include '../../model/Users.class.php';
        $rel = new Users( '', '' );
        $get_rel = $rel->getRelationUserCenter( $_SESSION['SessionIdUser'] );
        
        if( $_SESSION['SessionPrivilegy'] == 'administrador')
        {
            if( $get_rel[0] == '' || $get_rel[0] == null )
            {
                $view->replaceVarsTemplate( array('HEAD'=>include '../../view/head.html',
                                                'NAV'=>include '../../view/navbar_admin.php',
                                                'FORM'=> include "../../view/forms/user_no_assoc.php",
                                                'FOOT'=>include '../../view/foot.html'));
            }else{
                $_SESSION['SessionIdCenter'] = $get_rel[0];
                $view->replaceVarsTemplate(
                    array("HEAD" => include "../../view/head.html",
                            "FORM" => include "../../view/forms/main/main_admin.php",
                            "NAV" => include "../../view/navbar_admin.php",
                            "FOOT"=> include "../../view/foot.html")
                    );
            }
            
        }else{
            if( $get_rel[0] == '' || $get_rel[0] == null )
            {
                $view->replaceVarsTemplate( array('HEAD'=>include '../../view/head.html',
                                                'NAV'=>include '../../view/navbar_user.php',
                                                'FORM'=> include "../../view/forms/user_no_assoc.php",
                                                'FOOT'=>include '../../view/foot.html'));
            }else{
                $_SESSION['SessionIdCenter'] = $get_rel[0];
                $view->replaceVarsTemplate( array('HEAD'=>include '../../view/head.html',
                                                'NAV'=>include '../../view/navbar_user.php',
                                                'FORM'=>include "../../view/forms/main/main_user.php",
                                                'FOOT'=>include '../../view/foot.html'));
            }
            
        }
        $view->viewTemplate();
    }
}