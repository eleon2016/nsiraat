<?php

$cause = $_POST['cause'];

$upload_folder ='../../images/uploads/supports_assistances';
$nombre_archivo = $_FILES["archivo"]["name"];
$tipo_archivo = $_FILES["archivo"]["type"];
$tamano_archivo = $_FILES["archivo"]["size"];
$tmp_archivo = $_FILES["archivo"]["tmp_name"];

$archivador = $upload_folder . "/" . $nombre_archivo;

if( $tipo_archivo != 'application/pdf' ){
    echo json_encode(array("status"=>'Error', 'msg'=>'El archivo selecionado, prrsenta problemas o no tiene un extensión válida' ));
}elseif( $tamano_archivo > 2000000 ){ //2Mib
    echo json_encode(array("status"=>'Error', 'msg'=>'El tamaño del archivo exede al límite permitido' ));
}else{
    if (!move_uploaded_file($tmp_archivo, $archivador))
        echo json_encode(array("status"=>'Error', 'msg'=>'Ocurrió un error al tratar de subir el archivo' ));
    else{
        include '../../php/functions.php';
        $hash = GeraHash(10);
        echo $hash;
    }
       // echo json_encode(array("status"=>'Success','tamano'=>$tamano_archivo));
}