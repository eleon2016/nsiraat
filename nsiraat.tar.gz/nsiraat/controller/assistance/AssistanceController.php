<?php
//session_start();

class AssistanceController
{
    function __construct()
    {
        
    }
    
    public function init()
    {
        include '../../php/mTemplate.class.php';
        $view = new MountTemplate('basicTemplate',0,'html');
        if( $_SESSION['SessionPrivilegy'] == 'administrador')
        {
            $view->replaceVarsTemplate(
                    array("HEAD"    => include "../../view/head.html",
                            "FORM"  => include "../../view/forms/assistance/assistance.php",
                            "NAV"   => include "../../view/navbar_admin.php",
                            "FOOT"  => include "../../view/foot.html")
                    );
        }else{
            $view->replaceVarsTemplate(
                    array('HEAD'    =>include '../../view/head.html',
                            'NAV'   =>include '../../view/navbar_user.php',
                            'FORM'  =>include '../../view/forms/assistance/assistance.php',
                            'FOOT'  =>include '../../view/foot.html')
                    );
        }
        $view->viewTemplate();
    }
    
    public function MarkAssistance( $idPersonal, $obs )
    {
        session_start();
        include '../../model/Assistance.class.php';
        $check = new Assistance();
        $check->MarkAssistance( $idPersonal, $_SESSION['SessionIdCenter'], $obs );
    }
    
    public function ListAssistanceToday( $idCenter )
    {
        //session_start();
        include '../../../model/Assistance.class.php';
        $list = new Assistance();
        return $list->ListAssistanceToday( $idCenter );
    }
    
    public function ListAssistanceNoValidateByPersonal( $idPersonal )
    {
        include '../../../model/Assistance.class.php';
        $assistance_no_validate = new Assistance();
        return $assistance_no_validate->ListAssistanceNoValidateByPersonal( $idPersonal );
    }
    
    public function ValidateAssistance( $idAssistance, $idPersonal )
    {
        include '../../model/Assistance.class.php';
        $validate_assistance = new Assistance();
        echo $validate_assistance->ValidateAssistance( $idAssistance, $idPersonal );
    }
    
    public function InvalidateAssistance( $idAssistance, $idPersonal, $observations )
    {
        include '../../model/Assistance.class.php';
        $invalidate_assistance = new Assistance();
        echo $invalidate_assistance->InvalidateAssistance( $idAssistance, $idPersonal, $observations );
    }
    
    public function JustifyAssistance(  $cause, $obs, $idAssistance, $idPersonal, $fileName, $fileType, $fileSize, $fileTmpName, $fileError )
    {
        $upload_folder ='../../images/uploads/supports_assistances';
        
        if( $fileError > 0 )
        {
            echo json_encode(array('status'=>'fileError', 'msg'=>'El archivo que intenta subir, tiene errores'));
        
        }elseif( strpos($fileName,".pdf") || strpos($fileName,".PDF") ){
            
            if( file_exists( $upload_folder. "/" .$fileName )) {
                echo json_encode(array('status'=>'nameDuplicate', 'msg'=>'Ya existe un archivo con este nombre, intente cambiarle el nombre'));
        
            }elseif( $fileSize/1024 <= 2048){
                $archivador = $upload_folder . "/" . $fileName;
                
                if (!move_uploaded_file($fileTmpName, $archivador))
                    echo json_encode(array("status"=>'upError', 'msg'=>'Ocurrió un error al tratar de subir el archivo, intente con otro archivo' ));
                else{
                    include '../../php/functions.php';
                    $newName = uniqid('ja_');
                    $new_archivador = $upload_folder . "/" . $newName.'.pdf';
                    if (rename ($archivador, $new_archivador))
                    {
                        include '../../model/Assistance.class.php';
                        $justify_assistance = new Assistance();
                        echo $justify_assistance->JustifyAssistence( $cause, $obs, $idAssistance, $idPersonal, $newName );
                    }
                }   
            }else{
                echo json_encode(array('status'=>'sizeError', 'msg'=>'El tamaño máximo de los archivo debe ser 2Mb.'));
            }
        }else{
            echo json_encode(array('status'=>'extError', 'msg'=>'Solo se admiten archivos .pdf'));
        }
    }
    
}