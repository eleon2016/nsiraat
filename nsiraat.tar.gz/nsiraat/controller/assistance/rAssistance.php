<?php

$method = $_POST['method'];

switch( $method )
{
    case 'getNamesPersonalByCi':
        include '../personal/PersonalController.php';
        $nPersonal = new PersonalController();
        $nPersonal->getNamesPersonalByCi( $_POST['ci'] );
        break;
    
    case 'MarkAssistance':
        include '../assistance/AssistanceController.php';
        $nCheck = new AssistanceController();
        $nCheck->MarkAssistance( $_POST['id'], trim(utf8_encode($_POST['obs'])) );
        break;
    
    case 'ValidateAssistance':
        include '../assistance/AssistanceController.php';
        $Validate = new AssistanceController();
        $Validate->ValidateAssistance( $_POST['IdAssistance'], $_POST['IdPersonal'] );
        break;
    
    case 'InValidateAssistance':
        include '../assistance/AssistanceController.php';
        $Validate = new AssistanceController();
        $Validate->InvalidateAssistance( $_POST['IdAssistance'], $_POST['IdPersonal'], $_POST['Observations'] );
        break;
    
    case 'JustifyAssistance':
        include '../assistance/AssistanceController.php';
        $Justify = new AssistanceController();
        $Justify->JustifyAssistance( $_POST['cause'], $_POST['obs'], $_POST['idAssistance'], $_POST['idPersonal'],
                                     $_FILES["archivo"]["name"], $_FILES["archivo"]["type"],
                                     $_FILES["archivo"]["size"], $_FILES['archivo']['tmp_name'],
                                     $_FILES['archivo']['error'] );
        break;
    
    default:
        break;
}