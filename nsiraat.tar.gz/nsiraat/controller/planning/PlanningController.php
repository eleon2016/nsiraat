<?php

class PlanningController
{
    function __construct()
    {
        
    }
    
    public function init()
    {
        include '../../php/mTemplate.class.php';
        $view = new MountTemplate('basicTemplate',0,'html');
        if( $_SESSION['SessionPrivilegy'] == 'administrador')
        {
            $view->replaceVarsTemplate(
                    array("HEAD"    => include "../../view/head.html",
                            "FORM"  => include "../../view/forms/planning/planning.php",
                            "NAV"   => include "../../view/navbar_admin.php",
                            "FOOT"  => include "../../view/foot.html")
                    );
        }else{
            $view->replaceVarsTemplate(
                    array('HEAD'    =>include '../../view/head.html',
                            'NAV'   =>include '../../view/navbar_user.php',
                            'FORM'  =>include '../../view/forms/planning/planning.php',
                            'FOOT'  =>include '../../view/foot.html')
                    );
        }
        $view->viewTemplate();
    }
    
    public function MakeNewAnualPlan( $plan_name, $plan_default )
    {
        session_start();
        include '../model/Planning.class.php';
        $edition_status = 'open';
        $new_plan = new Planning();
        echo $new_plan->MakeNewAnualPlan( $plan_name, $plan_default, $_SESSION['SessionIdCenter'], $edition_status);
    }

    public function SaveDetailsNewPlan($id_plan, $goals, $challenges, $activities, $indicators, $mounths, $responsibles, $place, $orige)
    {
        include '../../model/Planning.class.php';
        $save_details = new Planning();
        echo $save_details->SaveDetailsNewPlan($id_plan, $goals, $challenges, $activities, 
                                                $indicators, $mounths, $responsibles, $place, $orige);
    }

    public function ListAnualPlanByCenter($id_center)
    {
        include '../../../model/Planning.class.php';
        $n_planner = new Planning();
        return $n_planner->ListAnualPlanByCenter($id_center);
    }

    public function GetAnualPlanNameById($id_plan)
    {
        include '../../../model/Planning.class.php';
        $name = new Planning();
        return $name->GetAnualPlanNameById($id_plan);
    }

    public function GetGoalsByIdPlan($id_plan)
    {
        include_once '../../../model/Planning.class.php';
        $obj_goals = new Planning();
        return $obj_goals->GetGoalsByIdPlan($id_plan);
    }

    public function GetChallengesByIdGoal($id_goal)
    {
        include_once '../../../model/Planning.class.php';
        $obj_challenges = new Planning();
        return $obj_challenges->GetChallengesByIdGoal($id_goal);
    }

    public function GetActivitiesByIdGoal($id_goal)
    {
        include_once '../../../model/Planning.class.php';
        $obj_activities = new Planning();
        return $obj_activities->GetActivitiesByIdGoal($id_goal);
    }

    public function GetIndicatorsByIdGoal($id_goal)
    {
        include_once '../../../model/Planning.class.php';
        $obj_indicators = new Planning();
        return $obj_indicators->GetIndicatorsByIdGoal($id_goal);
    }

    public function GetMounthsByIdGoal($id_goal)
    {
        include_once '../../../model/Planning.class.php';
        $obj_mounths = new Planning();
        return $obj_mounths->GetMounthsByIdGoal($id_goal);
    }

    public function GetResponsiblesByIdGoal($id_goal)
    {
        include_once '../../../model/Planning.class.php';
        $obj_responsibles = new Planning();
        return $obj_responsibles->GetResponsiblesByIdGoal($id_goal);
    }

    public function DeleteAnualPlan($id_plan)
    {
        include_once '../model/Planning.class.php';
        $obj_delete = new planning();
        echo $obj_delete->DeleteAnualPlan($id_plan);
    }

    public function CloseEditionPlan($id_plan, $id_center)
    {
        include_once '../model/Planning.class.php';
        $obj_close = new planning();
        echo $obj_close->CloseEditionPlan($id_plan, $id_center);
    }
}