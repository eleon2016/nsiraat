<?php

$method = $_POST['method'];

switch( $method )
{
    case 'MakeNewAnualPlan':
        include('../planning/PlanningController.php');
        $new_plan = new PlanningController();
        $new_plan->MakeNewAnualPlan( $_POST['PlanName'], $_POST['DefaultPlan'] );
        break;

    case 'SaveDetailsNewPlan':
    	include '../planning/PlanningController.php';
    	$save = new PlanningController();
    	$save->SaveDetailsNewPlan( $_POST['IdPlan'],$_POST['Goal'],$_POST['Challenges'],$_POST['Activities'], 
    								$_POST['Indicators'],$_POST['Mounths'],$_POST['Responsibles'],$_POST['Place'],$_POST['Orige'] );
    	break;
    
    default:
        break;
}