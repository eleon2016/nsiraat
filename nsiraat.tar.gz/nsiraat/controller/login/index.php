<?php

include 'LoginController.php';
$login = new Login();
$login->init();
