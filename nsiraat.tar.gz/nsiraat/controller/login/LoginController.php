<?php

class Login
{
    function __construct()
    {
        
    }
    
    public function init()
    {
        include '../../php/mTemplate.class.php';
        $view = new MountTemplate('basicTemplate',0,'html');
        $view->replaceVarsTemplate( array('HEAD'=>include '../../view/head.html',
                                          'NAV'=>include '../../view/navbar.html',
                                          'FORM'=>include '../../view/forms/login/login.html',
                                          'FOOT'=>include '../../view/foot.html'));
        $view->viewTemplate();
        //echo $view;
    }
    
    public function ValidateUsers( $user,$password )
    {
        include '../../model/Users.class.php';
        $this->user = new Users( $user,$password );
        $rqs = $this->user->ValidateUsers();
        if( $rqs[0] != '' || $rqs[0] != null )
        {
            $this->MakeDataSession( $rqs );
            echo 'Success';
        }else{
            echo 'Empty';
        }
    }
    
    private function MakeDataSession( $rqs )
    {
        session_start();
        $_SESSION['SessionKey'] = '1db6d112c80273f1b76a45f6ecc76f7a'; //NOTE: md5sum - nsiraat
        $_SESSION['SessionIdUser'] = $rqs[0];
        $_SESSION['SessionUser'] = $rqs[1];
        $_SESSION['SessionPrivilegy'] = $rqs[2];
        $_SESSION['SessionIdCenter'] = $rqs[3];
    }
    
}
