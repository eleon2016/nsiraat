$(function () {
    $("#txtUsuario").focus();
    $("#formlogin").submit(function(event){
        var data = {
            'user' : $("#txtUsuario").val(),
            'passwd' : $("#txtClave").val(),
            'method' : 'ValidateUsers'
        };
        $.ajax({
            data: data,
            url: "rUsers.php",
            type: 'post',
            dataType: 'html',
            beforeSend: function(){
                
            },
            success: function(ajaxResponse){
                if ( ajaxResponse == 'Empty') {
                    $('#divMessage').html('<strong>¡Error!</strong> Datos incorrectos. Rectifique.');
                    $('#divMessage').slideDown('slow').delay(2500).slideUp('slow');
                }else{
                    $(location).attr('href','../main/');
                }
            }
        });
        
        event.preventDefault();
    });
});