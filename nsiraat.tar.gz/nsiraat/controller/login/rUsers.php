<?php

include 'LoginController.php';

$user = trim( $_POST['user'] );
$password = trim( $_POST['passwd'] );
$method = $_POST['method'];

switch($method)
{
    case 'ValidateUsers':
        $login = new Login();
        $login->ValidateUsers($user,$password);
        break;
    default:
        break;
}