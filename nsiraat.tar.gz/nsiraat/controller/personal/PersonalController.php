<?php
//session_start();

class PersonalController
{
    function __construct()
    {
        
    }
    
    public function init()
    {
        
    }
    
    public function getNamesPersonalByCi( $ci )
    {
        include '../../model/Personal.class.php';
        $nPersonal = new PersonalModel();
        $names = $nPersonal->getNamesPersonalByCi( $ci );
        if($names[0] != '' || $names[0] != null )
        {
            echo json_encode( array( 'Status'=>'Success',
                                'Id'=>$names[0],
                                'Name'=>trim(ucwords(utf8_decode($names[1]))),
                                'Last_Name'=>trim(ucwords(utf8_decode($names[2]))) )
                         );
        }else{
            echo json_encode( array( 'Status'=>'Error') );
        }
    }
    
    public function getNamesPersonalByCenter( $idCenter )
    {
        include '../../../model/Personal.class.php';
        $list_names_personal = new PersonalModel();
        return $list_names_personal->getNamesPersonalByCenter( $idCenter );
    }
}
