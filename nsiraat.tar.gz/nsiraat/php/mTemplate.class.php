<?php

/**
 * 
 */
class MountTemplate {

    function __construct($template_file,$level,$ext) {
        if( $level == 0) {
            $this->tpl_file = '../../view/templates/' . $template_file . '.'.$ext;
            //$this->tpl_file = 'app/view/templates/' . $template_file . '.'.$ext;
        }else{
            $this->tpl_file = '../view/templates/' . $template_file . '.'.$ext;
        }
    }

    function replaceVarsTemplate($vars) {
        $this->vars = (empty($this->vars)) ? $vars : $this->vars . $vars;
    }

    function viewTemplate() {
        if (!($this->fd = @fopen($this->tpl_file, 'r'))) {
            sostenedor_error('error al abrir la plantilla ' . $this->tpl_file);
        } else {
            $this->template_file = fread($this->fd, filesize($this->tpl_file));
            fclose($this->fd);
            $this->mihtml = $this->template_file;
            $this->mihtml = str_replace("'", "\'", $this->mihtml);
            $this->mihtml = preg_replace('#\{([a-z0-9\-_]*?)\}#is', "' . $\\1 . '", $this->mihtml);
            reset($this->vars);
            while (list($key, $val) = each($this->vars)) {
                $$key = $val;
            }
            eval("\$this->mihtml = '$this->mihtml';");
            reset($this->vars);
            while (list($key, $val) = each($this->vars)) {
                unset($$key);
            }
            $this->mihtml = str_replace("\'", "'", $this->mihtml);
            // echo $this->mihtml;
            return $this->mihtml;
        }
    }
}
