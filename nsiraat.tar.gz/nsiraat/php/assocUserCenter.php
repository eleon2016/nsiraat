<?php
session_start();
include '../model/Users.class.php';

$idCenter = trim(utf8_encode(strtolower( $_POST['center'] )));

$assocUser = new Users('','');
$response = $assocUser->AssocUserCenter( $_SESSION['SessionIdUser'], $idCenter );
echo $response;