<?php
function GeraHash($qtd){
    //Under the string $Caracteres you write all the characters you want to be used to randomly generate the code.
    $Caracteres = 'ABCDEFGHIJKLMOPQRSTUVXWYZabcdefghijklmnopqrstuvwxyz0123456789_';
    $CantidadCaracteres = strlen($Caracteres);
    $CantidadCaracteres--;
    
    $Hash=NULL;
    for($x=1;$x<=$qtd;$x++){
        $Posicion = rand(0,$CantidadCaracteres);
        $Hash .= substr($Caracteres,$Posicion,1);
    }
    
    return $Hash;
}

?>