<?php
session_start();
require_once '../../api/dompdf/dompdf_config.inc.php';
require_once '../../model/Planning.class.php';
require_once '../../model/Centers.class.php';

$id_plan = $_GET['d'];

ini_set('date.timezone', 'America/caracas');
$date = date('d/m/Y');
$hour = date('H:i:s');

$obj_plan = new Planning();
$n_name =  $obj_plan->GetAnualPLanNameById( $id_plan );
$name_plan = trim(utf8_decode(ucwords( $n_name[0] )));

$obj_center = new CentersModel();
$n_name_center = $obj_center->GetNameCenterById( $n_name[1] );

$obj_goals = new Planning();
$goals = $obj_goals->GetGoalsByIdPlan( $id_plan ); 


//Construcción de la tabla con los datos de plan operativo
$i=1; 
$datas = "<tr>";
foreach($goals as $goal){
	//Metas
	$datas .= "<td>".$i."</td>
				<td>".trim(utf8_decode(ucfirst($goal['goal'])))."</td>";

	//Desafios
	$obj_challenges = new Planning();
	$challenges = $obj_challenges->GetChallengesByIdGoal( $goal['idGoal'] );
	$datas .= "<td>";
	$ch = 1;
	foreach ($challenges as $challenge){
		$datas .= $ch.'.- '.trim(utf8_decode(ucfirst($challenge['challenge'])))."<br /><br />";
		$ch++;
	}
	$datas .= "</td>";

	//Actividades
	$obj_activities = new Planning();
	$activities = $obj_activities->GetActivitiesByIdGoal( $goal['idGoal'] );
	$datas .= "<td>";
	$ac = 1;
	foreach ($activities as $activitie){ 
		$datas .= $ac.'.- '.trim(utf8_decode(ucfirst($activitie['activitie']))).'<br /><br />';
		$ac++;
	}
	$datas .= "</td>";

	//Indicadores
	$obj_indicators = new Planning();
	$indicators = $obj_indicators->GetIndicatorsByIdGoal( $goal['idGoal'] );
	$datas .= "<td>";
	$in = 1;
	foreach ($indicators as $indicator){ 
		$datas .= $in.'.- '.trim(utf8_decode(ucfirst($indicator['indicator']))).'<br /><br />';
		$in++;
	}
	$datas .= "</td>";

	//Meses
	$obj_mounths = new Planning();
	$mounths = $obj_mounths->GetMounthsByIdGoal( $goal['idGoal'] );
	$datas .= "<td>";
	foreach ($mounths as $mounth){ 
		$datas .= trim(utf8_decode(ucfirst($mounth['mounth']))).'<br />';
	}
	$datas .= "</td>";

	//Lugar
	$datas .= "<td>".trim(utf8_decode(ucfirst($goal['place'])))."</td>";

	//Responsables
	$obj_responsibles = new Planning();
	$responsibles = $obj_responsibles->GetResponsiblesByIdGoal( $goal['idGoal'] );
	$datas .= "<td>";
	foreach ($responsibles as $responsible){ 
		$datas .= trim(utf8_decode(ucwords($responsible['names']))).' '.trim(utf8_decode(ucwords($responsible['last_names']))).'<br /><br />';
	}
	$datas .= "</td>";
}
$datas.= "</tr>";

$img = '../../api/images/cintillo_1.png';

$content = "
<html>
	<head>
		<meta charset='utf-8'>
	</head>
	<body style='font-size:10px;'>
		<img src='cintillo.png' width=100% height=100px />
		<div style='margin:0 20px 10px 20px;'>
			
			<center><h1>Plan Operativo Anual</h1></center>
			<span><b>Nombre: </b>".trim(utf8_decode(ucwords( $n_name[0] )))."</span><br />
			<span><b>Centro Informático: </b>".trim(utf8_decode(ucwords($n_name_center[0])))."</span><br />
			<span><b>Creado el:</b>  ".$n_name[3]."</span><br />
			<div style='text-align:right;'>
				<span><i>Siraat - Generado por <b>".$_SESSION['SessionUser']."</b> el ".$date." - ".$hour."</i></span>
			</div>
			<br><br>
			<table style='font-size:10pt; border-collapse:collapse;' width=100% border=1px>
				<tr bgcolor='#cccccc' style='font-weight:bold;'>
					<td>#</td>
					<td>Metas</td>
					<td>Desaf&iacute;os Calidad Ed.</td>
					<td>Actividades</td>
					<td>Indicadores</td>
					<td>Meses</td>
					<td>Lugar</td>
					<td>Responsables</td>
				</tr>".$datas."
			</table>
		</div>
	</body>
</html>
";

$dompdf = new DOMPDF();
//$dompdf->load_html( file_get_contents( "../view/forms/planning/data_anual_plan_pdf.php" ) );
$dompdf->load_html( $content );
$dompdf->set_paper('letter', 'landscape');
$dompdf->render();
$dompdf->stream($name_plan.".pdf");

//echo $content;