<?php session_start(); ?>
<form id="formSelectPersonal">
    <div class="col-md-4">
        Seleccione la persona:
        <?php
            include '../../../controller/personal/PersonalController.php';
            $centers = new PersonalController();
            $datas = $centers->getNamesPersonalByCenter( $_GET['IdCenter'] );
        ?>
        
        <select class="form-control" id="SelectPersonal">
            <?php foreach( $datas as $data ): ?>
                <option value="<?= $data['IdPersonal']; ?>">
                <?= ucwords(utf8_decode(trim($data['names']))).' '.ucwords(utf8_decode(trim($data['last_names']))); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <div class="col-md-3">
        <br />
        <button type="submit" class="btn btn-success btn-block shadow-z-1">Listar asistencias</button>
    </div>
</form>