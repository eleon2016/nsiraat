<script src="../../js/assistance/assistance.js"></script>
<div class="container" id="ContainerTime" style="display: none;">
  <div class="row">
    <div class="col-md-12"><br /><br />
      <!--<div class="page-header">-->
      <!--  <h3>Módulos del usuario</h3>-->
      <!--</div>-->
      
      <div class="panel panel-default shadow-z-1">
        <div class="panel-body">
          <div class="page-header">
            <h3><img src="../../api/images/check-hour.png" width="32" height="32"> Asistencias</h3>
            <span class="text-muted small">
                Este módulo contienen todas las herramientas necesarias para realizar el marcado y reportes de las
                asistencias del personal que labora en su centro informático, asi como también, la oportunidad de
                validar los dias de permisos, vacaciones o ausencias (justificadas e injustificadas).
            </span>
          </div>
          
          <div class="row">
            <br />
            <div class="col-md-2">
              <button type="button" class="btn btn-primary btn-block shadow-z-1" id="Check">
                <span  class="glyphicon glyphicon-check"></span> Marcar
              </button>
              <button type="button" class="btn btn-primary btn-block shadow-z-1" id="List">
                <span class="glyphicon glyphicon-list"></span> Ver hoy
              </button>
              <?php if( $_SESSION['SessionPrivilegy'] == 'administrador') { ?>
                <button type="button" class="btn btn-primary btn-block shadow-z-1" id="Valid">
                  <span class="glyphicon glyphicon-thumbs-up"></span> Validar
                </button>
              <?php } ?>
            </div>
            
            <div class="col-md-10" id="FormTime"></div>
          </div>
        
        </div>
      </div>
    </div>
  </div>
</div>