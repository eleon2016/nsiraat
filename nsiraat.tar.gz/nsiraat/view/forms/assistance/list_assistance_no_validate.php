<?php
session_start();
include '../../../controller/assistance/AssistanceController.php';
$nList = new AssistanceController();
$List = $nList->ListAssistanceNoValidateByPersonal( $_GET['IdPersonal'] );
?>
<div class="row">
    <div class="col-md-12 table-responsive"><br />
        <?php  if(count($List) != 0) : ?>
        <table class="table table-condensed">
            <thead>
                <tr class="active">
                    <th>#</th>
                    <th>Fecha</th>
                    <th>H. entrada</th>
                    <th>H. salida</th>
                    <th>Observación</th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i=1;
                    foreach($List as $data): ?>
                        <tr>
                            <td><?php echo $i; $i++; ?></td>
                            <td><?php echo $data["date"]; ?></td>
                            <td><?php echo $data["hour_in"]; ?></td>
                            <td><?php echo $data["hour_out"]; ?></td>
                            <td><?php echo trim(utf8_decode(ucfirst($data["observation"]))); ?></td>
                            <td>
                                <button type="button" class="btn btn-warning shadow-z-1 glyphicon glyphicon-ok-sign" title="Validar"
                                        onclick="ValidateAssistance(<?= $data['IdAssistance']; ?>,<?= $_GET['IdPersonal'] ?>);">
                                </button>
                            </td>
                            <td>
                                <button type="button" class="btn btn-danger shadow-z-1 glyphicon glyphicon-remove-sign" title="Invalidar"
                                        onclick="ViewFormInvalidateAssistance(<?= $data['IdAssistance']; ?>,<?= $_GET['IdPersonal'] ?>);">
                                </button>
                            </td>
                            <td>
                                <button type="button" class="btn btn-primary shadow-z-1 glyphicon glyphicon-cog" title="Justificar"
                                        onclick="ViewFormJustifyAssistance(<?= $data['IdAssistance']; ?>,<?= $_GET['IdPersonal'] ?>);">
                                </button>
                            </td>
                        </tr>                      
                    <?php endforeach;
                ?>
            </tbody>
        </table>
        <?php else: ?>
            <div class="alert alert-info">Todos los registros de esta persona, han sido validados.</div>
        <?php endif; ?>
    </div>
</div>