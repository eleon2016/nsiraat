<div class="row well">
    <form id="formInvalidateAssistance">
        <input type="hidden" id="IdAssistance" value="<?= $_GET['IdAssistance']; ?>">
        <input type="hidden" id="IdPersonal" value="<?= $_GET['IdPersonal']; ?>">
        <div class="row">
            <div class="col-md-8">
                <strong>Escriba las causas por las que es inválido el registro::</strong>
                <textarea class="form-control" id="txtObservations" required=true></textarea>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4"><br />
                <button type="submit" class="btn btn-danger btn-block shadow-z-1">Invalidar registro</button>
            </div>
            <div class="col-md-4"><br />
                <button type="button" class="btn btn-default btn-block shadow-z-1"
                        onclick="CancelInvalidateAssistance(<?= $_GET['IdPersonal'] ?>)">
                    Cancelar
                </button>
            </div>
        </div>
    </form>
</div>