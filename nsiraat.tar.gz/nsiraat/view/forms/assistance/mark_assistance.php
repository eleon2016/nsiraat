<?php session_start();?>
<!--<script src="../../js/assistance/MarkAssistance.js"></script>-->
<div class="row">
    <div class="col-md-12" style="border-bottom: 1px solid; border-bottom-color: #DBDBDB;">
        <strong><span class="glyphicon glyphicon-check"></span> Marcar Asistencias</strong>
    </div>
</div>
<br />
<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-7" style="">
                <form id="FormCheckTime" method="POST">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="alert" id="DivMessage" style="display:none;"></div>
                            Escriba su número de cédula:
                            <input type="text" class="form-control" id="txtCedNumber" required=true><br />

                            Observaciones:
                            <textarea class="form-control" id="txtObs"></textarea>
                        </div>
                        <div class="col-md-3">
                            <br />
                            <button type="submit" class="btn btn-success btn-block shadow-z-1">Marcar</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-warning" id="DivMessageHora" style="display:none;">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>