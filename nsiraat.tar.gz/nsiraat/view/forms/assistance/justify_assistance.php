<div class="row well">
    <form enctype="multipart/form-data" id="formJustifyAssistance" method="post">
        
        <input type="hidden" id="IdAssistance" value="<?= $_GET['IdAssistance']; ?>">
        <input type="hidden" id="IdPersonal" value="<?= $_GET['IdPersonal']; ?>">
        
        <div class="row">
            <div class="col-md-8">
                <strong>Descripción de la justificación:</strong>
                <input type="text" class="form-control" id="txtJustifyCause" required=true>
            </div>
        </div>
        <br />
        <div class="row">
            <div class="col-md-8">
                <strong>Observación:</strong>
                <textarea class="form-control" id="txtJustifyObs"></textarea>
            </div>
        </div>
        <br />
        <div class="row">
            <div class="col-md-8">
                <strong>Seleccione archivo</strong><br />
                <small><span class="muted text-info">Sólo admiten archivos <strong>.pdf</strong> con un tamaño máximo de <strong>2Mb</strong>. </span></small>
                <input type="file" name="archivoImage" id="archivoImage" class="btn btn-default btn-block"/>
                <div id="MessageUploadImage" style="display: none;">
                    <small>
                        <span class="text-danger" id="Message">
                            
                        </span>
                    </small>
                </div>
                <br />
            </div>
        </div>
        <br />
        <div class="row">
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary btn-block shadow-z-1" >Justificar registro</button>
                <!--<button type="submit" class="btn btn-success btn-block shadow-z-1">Justificar registro</button>-->
            </div>
            <div class="col-md-4">
                <button type="button" class="btn btn-default btn-block shadow-z-1"
                        onclick="CancelJustifyAssistance(<?= $_GET['IdPersonal'] ?>)">
                    Cancelar
                </button>
            </div>
        </div>
        
    </form>
</div>