<?php session_start(); ?>
<div class="row">
    <div class="col-md-12" style="border-bottom: 1px solid; border-bottom-color: #DBDBDB;">
        <strong><span class="glyphicon glyphicon-thumbs-up"></span> Validar Asistencias</strong>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-12"><br />
                <div class="alert alert-warning">
                    <small>
                        <strong>¡Aviso!</strong>
                        Esta operación es delicada, pues, usted tendrá la autoridad confirmar/aprobar o no, la
                        información que a continuación será mostrada, comprometiendo así, su ética y credibilidad profesional
                        y la de sus subornidanos.<br /><br />Desde la Coordinación Zonal de
                        Informática Educativa del estado Sucre, estamos confiados en que usted hará una validación sana y objetiva
                        basados en los princípios de la profesión docente.
                    </small>
                </div>
            </div>
        </div>
        <?php
        if($_SESSION['SessionPrivilegy'] == 'administrador'): ?>
            <div clas="row">
                <div class="col-md-4">
                    <form id="formASelectCenters">
                        Selecione el centro informático:
                        <?php
                            include '../../../controller/centers/CentersController.php';
                            $centers = new CentersController();
                            $datas = $centers->getAllCenters(1);
                        ?>
                        
                        <select class="form-control" id="SelectCenter">
                            <?php foreach( $datas as $data ): ?>
                                <option value="<?= $data['IdCenter']; ?>"><?= ucwords(utf8_decode($data['center_name'])); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                    <br />
                </div>
                <div id="DivSelectSelectPersonal"></div>
                
            </div>
        <?php endif; ?>
        <div clas="row">
            <div class="col-md-12">
                <div id="DivViewListAssitanceNoValidate"></div>
            </div>
        </div>
    </div>
</div>