<?php session_start(); ?>
<div class="row">
    <div class="col-md-12" style="border-bottom: 1px solid; border-bottom-color: #DBDBDB;">
        <strong><span class="glyphicon glyphicon-list"></span> Listar Asistencias</strong>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-7"><br />
                <div class="alert alert-info">
                    <small>Se listarán las asistencias correspondiente a la fecha:<span class="text-success">
                    <strong>
                    <?php
                        ini_set('date.timezone', 'America/caracas');
                        echo date('d/m/Y');
                    ?>
                    </strong>
                    </span></small>
                </div>
            </div>
        </div>
        <?php
        if($_SESSION['SessionPrivilegy'] == 'administrador'): ?>
            <div clas="row">
                <form id="formFindAssistanceBySelectCenter">
                    <div class="col-md-4">
                        Selecione el centro informático:
                        <?php
                            include '../../../controller/centers/CentersController.php';
                            $centers = new CentersController();
                            $datas = $centers->getAllCenters(1);
                        ?>
                        
                        <select class="form-control" id="nIdcenter">
                            <?php foreach( $datas as $data ): ?>
                                <option value="<?= $data['IdCenter']; ?>"><?= ucwords(utf8_decode($data['center_name'])); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <br />
                    </div>
                    <div class="col-md-3">
                        <br />
                        <button type="submit" class="btn btn-success btn-block shadow-z-1">Listar asistencias</button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div clas="row">
                <div class="col-md-4"><br />
                <form id="formFindAssistanceByCenter">
                    <button type="submit" class="btn btn-info btn-block shadow-z-1">Mostrar las asistencias del centro</button>
                </form>
                </div>
            </div>
        <?php endif; ?>
        <div id="DivViewList"></div>
    </div>
</div>