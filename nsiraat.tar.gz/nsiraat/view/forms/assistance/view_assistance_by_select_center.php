<?php
    session_start();

    include '../../../controller/assistance/AssistanceController.php';
    $idCenter = $_GET['IdCenter'];
    $nList = new AssistanceController();
    $List = $nList->ListAssistanceToday( $_GET['IdCenter'] );
    
?>
<div class="row">
    <div class="col-md-12" style="size: 10px;"><br />
        <?php  if(count($List) != 0) : ?>
        <table class="table table-condensed">
            <thead>
                <tr class="active">
                    <th>#</th>
                    <th>C.I.</th>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>H. entrada</th>
                    <th>H. salida</th>
                    <th>Observación</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
                $i=1;
                foreach($List as $data): ?>
                    <tr>
                        <td><?php echo $i; $i++; ?></td>
                        <td><?php echo $data["ci"]; ?></td>
                        <td><?php echo trim(utf8_decode(ucwords( $data["names"] ))); ?></td>
                        <td><?php echo trim(utf8_decode(ucwords( $data["last_names"] ))); ?></td>
                        <td><?php echo $data["hour_in"]; ?></td>
                        <td><?php echo $data["hour_out"]; ?></td>
                        <td><?php echo trim(utf8_decode(ucfirst( $data["observation"] ))); ?></td>
                        <td><?php
                            if( trim(utf8_decode($data["validation"])) == 'Válido')
                                echo '<span class="label label-success">'.trim(utf8_decode($data["validation"])).'</span>';
                            elseif( trim(utf8_decode($data["validation"])) == 'Inválido')
                                echo '<span class="label label-danger">'.trim(utf8_decode($data["validation"])).'</span>';
                            else
                                echo '<span class="label label-warning">'.trim(utf8_decode($data["validation"])).'</span>';
                        ?></td>
                    </tr>                     
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
            <div class="alert alert-info">Este centro no ha registrado asistencias hoy.</div>
        <?php endif; ?>
    </div>
</div>