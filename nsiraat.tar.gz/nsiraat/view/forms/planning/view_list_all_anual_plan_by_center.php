<div class="row">
    <div class="col-md-12" style="border-bottom: 1px solid; border-bottom-color: #DBDBDB;">
        <strong><span class="glyphicon glyphicon-list"></span> Listado de Planes Operativos existentes</strong>
    </div>
</div>
<br />
<div class="row" id="DivAlertDeletePOA" style="display:none;">
    <div class="col-md-12">
        <div class="alert alert-danger">
            El registro se eliminó de la base de datos correctamente.
        </div>
    </div>
</div>
<br />
<div class="row">
    <div class="col-md-12">
        <?php
            session_start(0);
            include '../../../controller/planning/PlanningController.php';
            $planners = new PlanningController();
            $list_plan = $planners->ListAnualPlanByCenter( $_POST['IdCenter'] );
            if( count($list_plan) > 0 ): ?>
                <table class="table table-condensed table-responsive" style="font-size: 14px;">
                    <thead>
                        <tr class="active">
                            <th style="width:30px;">#</th>
                            <th>Planes Operativos</th>
                            <th>Año</th>
                            <th>Edición</th>
                            <th style="width:120px;"></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        $i = 1;
                        foreach ($list_plan as $data): ?>
                            <tr>
                                <td><?php echo $i; $i++; ?></td>
                                <td><?php echo trim(utf8_decode(ucfirst($data['plan_name']))); ?></td>
                                <td><?php echo $data['plan_year']; ?></td>
                                <td>
                                    <?php
                                        if($data['edition_status'] == 'open'): ?>
                                            <span class="label label-success">Abierta</span>
                                        <?php else: ?>
                                            <span class="label label-default">Cerrada</span>
                                        <?php endif; ?>
                                </td>
                                <td style="text-align:right;">
                                    <?php
                                        if($_SESSION['SessionPrivilegy'] == 'administrador'): 
                                            if($data['edition_status'] == 'open'): ?>
                                                <button type="button" class="btn btn-sm btn-default shadow-z-1" id="" 
                                                        onclick="ViewPlan(<?php echo $data['idPlan']; ?>);">
                                                    <span class="glyphicon glyphicon-search"></span>
                                                </button>

                                                <button type="button" class="btn btn-sm btn-default shadow-z-1" id=""
                                                        onclick="EditPlan(<?php echo $data['idPlan']; ?>);">
                                                    <span class="glyphicon glyphicon-edit"></span>
                                                </button>

                                                <button type="button" class="btn btn-sm btn-danger shadow-z-1" id=""
                                                        onclick="DeleteAnualPlan(<?php echo $data['idPlan']; ?>);">  
                                                    <span class="glyphicon glyphicon-trash"></span>
                                                </button>

                                            <?php else: ?>

                                                <button type="button" class="btn btn-sm btn-default shadow-z-1" id="" 
                                                        onclick="ViewPlan(<?php echo $data['idPlan']; ?>);">
                                                    <span class="glyphicon glyphicon-search"></span>
                                                </button>

                                                <a href="../../php/export_pdf/export_poa_pdf.php?d=<?php echo $data['idPlan']; ?>" class="btn btn-sm btn-default shadow-z-1">
                                                    <span class="glyphicon glyphicon-download-alt"></span>
                                                </a>
                                            <?php endif;
                                        else: 
                                            if($data['edition_status'] == 'open'): ?>
                                                <button type="button" class="btn btn-sm btn-default shadow-z-1" id="" 
                                                        onclick="ViewPlan(<?php echo $data['idPlan']; ?>);">
                                                    <span class="glyphicon glyphicon-search"></span>
                                                </button>

                                            <?php else: ?>

                                                <button type="button" class="btn btn-sm btn-default shadow-z-1" id="" 
                                                        onclick="ViewPlan(<?php echo $data['idPlan']; ?>);">
                                                    <span class="glyphicon glyphicon-search"></span>
                                                </button>

                                                <a href="../../php/export_pdf/export_poa_pdf.php?d=<?php echo $data['idPlan']; ?>" class="btn btn-sm btn-default shadow-z-1">
                                                    <span class="glyphicon glyphicon-download-alt"></span>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-danger">
                    El centro seleccionado no ha registrado Planes Operativos Anuales.
                </div>
            <?php endif; ?>
        </table>
    </div>
</div>