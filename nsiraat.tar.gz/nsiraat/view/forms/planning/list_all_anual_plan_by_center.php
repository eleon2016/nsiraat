<?php 
    session_start();
    if($_SESSION['SessionPrivilegy'] == 'administrador'): ?>
        <div clas="row">
            <div class="col-md-4">
                <form id="formASelectCenters">
                    Selecione el centro informático:
                    <?php
                        include '../../../controller/centers/CentersController.php';
                        $centers = new CentersController();
                        $datas = $centers->getAllCenters(1);
                    ?>
                    
                    <select class="form-control" id="SelectCenter" onclick="<">
                        <?php foreach( $datas as $data ): ?>
                            <option value="<?= $data['IdCenter']; ?>"><?= ucwords(utf8_decode($data['center_name'])); ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>
            <br />
            <button type="button" class="btn btn-success shadow-z-1" id="bttViewList">
                <span class="glyphicon glyphicon-edit"></span> Visualizar listado
            </button>      
        </div>
    <?php else: ?>
        <button type="button" class="btn btn-success shadow-z-1" onclick="ViewListAllAnualPanByCenter(<?php echo $_SESSION['SessionIdCenter']; ?>)">
            <span class="glyphicon glyphicon-edit"></span> Visualizar listado
        </button>
        <br />
<?php endif; ?>


<br />
<div id="DivListAllPlanByCenter"></div>
