<?php session_start(); ?>

<div class="row">
    <div class="col-md-12" style="border-bottom: 1px solid; border-bottom-color: #DBDBDB;">
        <strong><span class="glyphicon glyphicon-file"></span> Construir un Nuevo Plan Operativo Anual (P.O.A.)</strong>
    </div>
</div>
<br />
<div class="row" id="InitForm">
    <form id="FormMakeNewAnualPlan" method="post">
        <div class="row">
            <div class="col-md-10">
                
                <div class="alert alert-danger" id="MessageIsset" style="display: none;">
                    <strong>¡Error!</strong> El nombre suministrado ya está registrado, intente con otro diferente.
                </div>
                
                Escriba el nombre P.O.A. <small><i class="text-muted">(Max 70 caracteres)</i></small>
                <input type="text" class="form-control" id="NewAnualPlanName" maxlength=70 required=true>
                <span class="text-muted"><small>
                    Coloque un nombre intuitivo y fácil de recordar a su nuevo plan. <br />
                    <strong>Ejemplo: </strong>Plan Operativo Anual 2016-2017.
                </small></span>
                <!--<br /><br />-->
                <input type="checkbox" id="CheckDefault" checked=true style="display: none;">
                <!--¿Marcar este P.O.A. como el vigente?-->
            </div>
        </div>
        <br />
        <div class="row">
            <div class="col-md-3">
                <button type="submit" class="btn btn-block btn-success shadow-z-1">
                    <span class="glyphicon glyphicon-ok-sign"></span> 
                    Registrar el Nuevo P.O.A.
                </button>
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-block btn-default shadow-z-1">
                    <span class="glyphicon glyphicon-remove-sign"></span> 
                    Cancelar
                </button> 
            </div>
        </div>
    </form>
</div>
<div class="row" id="dataName" style="display: none;">
    <div class="col-md-12">
        <div class="alert alert-success">
            <div id="MessageName"></div>
        </div>
    </div>
</div>
<br />
<div class="row" id="divFormDetailsNewAnualPlan"></div>