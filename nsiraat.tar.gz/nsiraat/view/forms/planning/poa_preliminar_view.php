<?php 
	session_start();
	$id_plan = $_POST['IdPlan'];
	include '../../../controller/planning/PlanningController.php';
    $name_plan = new PlanningController();
	$n_name =  $name_plan->GetAnualPLanNameById( $id_plan );
?>
<div class="row">
	<!--style="border-bottom: 1px solid; border-bottom-color: #DBDBDB;" -->
	<div class="col-md-12">
		<div class="row">
		    <div class="col-md-8 text-warning">
		    	<input type="hidden" id="IdPlan" value="<?php echo $id_plan; ?>">
		        <span class="glyphicon glyphicon-eye-close"></span> Vista preliminar
		    </div>
		    <?php if($n_name[2] == 'open' && $_SESSION['SessionPrivilegy'] == 'administrador'): ?>
		    	<div class="col-md-4" style="text-align:right;">
		        	<button type="button" class="btn btn-sm btn-default shadow-z-1" id="btnEditionBack">
		        		<span class="glyphicon glyphicon-transfer"></span> Ir al modo edición
		        	</button>
		    	</div>
		    <?php endif; ?>
		</div>
	</div>
</div>

<br />
<div class="row">
    <div class="col-md-12">
        <span style="font-size: 24px; font-weight: bold;" class="text-primary">
        	<?php echo trim(utf8_decode(ucwords( $n_name[0] ))); ?>
        </span>
    </div>
</div>

<br />
<div class="row">
    <div class="col-md-12">
    	<?php
	        $obj_goals = new PlanningController();
	        $goals = $obj_goals->GetGoalsByIdPlan( $id_plan ); 
	        if (count($goals)!= 0): ?>
		        <table width="100%" border="1px" cellppading="2px" style="font-size:13px;" class="shadow-z-1">
		        	<tr style="background-color: silver; font-weight:bold; height:30px;">
			        	<td>&nbsp;#&nbsp; </td>
			        	<td>Metas</td>
			        	<td>Desafíos</td>
			        	<td>Actividades</td>
			        	<td>Indicadores</td>
			        	<td>Meses</td>
			        	<td>Lugar</td>
			        	<td>Responsables</td>
			        </tr>
	        		<?php 
	        			$i=1; 
	        			foreach($goals as $goal): ?>
				        <tr style="vertical-align:top;">
				        	<td style="text-align:center;"><?php echo $i; ?></td>
				        	<td><?php echo trim(utf8_decode(ucfirst($goal['goal']))); ?></td>
				        	<td>
				        		<?php 
				        			$obj_challenges = new PlanningController();
				        			$challenges = $obj_challenges->GetChallengesByIdGoal( $goal['idGoal'] );
				        			$ch = 1;
				        			foreach ($challenges as $challenge){ 
				        				echo $ch.'.- '.trim(utf8_decode(ucfirst($challenge['challenge']))).'<br /><br />';
				        				$ch++;
				        			}
				        		?>
				        	</td>
				        	<td>
								<?php 
				        			$obj_activities = new PlanningController();
				        			$activities = $obj_activities->GetActivitiesByIdGoal( $goal['idGoal'] );
				        			$ac = 1;
				        			foreach ($activities as $activitie){ 
				        				echo $ac.'.- '.trim(utf8_decode(ucfirst($activitie['activitie']))).'<br /><br />';
				        				$ac++;
				        			}
				        		?>
				        	</td>
				        	<td>
				        		<?php 
				        			$obj_indicators = new PlanningController();
				        			$indicators = $obj_indicators->GetIndicatorsByIdGoal( $goal['idGoal'] );
				        			$in = 1;
				        			foreach ($indicators as $indicator){ 
				        				echo $in.'.- '.trim(utf8_decode(ucfirst($indicator['indicator']))).'<br /><br />';
				        				$in++;
				        			}
				        		?>
				        	</td>
				        	<td>
				        		<?php 
				        			$obj_mounths = new PlanningController();
				        			$mounths = $obj_mounths->GetMounthsByIdGoal( $goal['idGoal'] );
				        			foreach ($mounths as $mounth){ 
				        				echo trim(utf8_decode(ucfirst($mounth['mounth']))).'<br />';
				        			}
				        		?>
				        	</td>
				        	<td><?php echo trim(utf8_decode(ucfirst($goal['place']))); ?></td>
				        	<td>
				        		<?php 
				        			$obj_responsibles = new PlanningController();
				        			$responsibles = $obj_responsibles->GetResponsiblesByIdGoal( $goal['idGoal'] );
				        			foreach ($responsibles as $responsible){ 
				        				echo trim(utf8_decode(ucwords($responsible['names']))).' '.trim(utf8_decode(ucwords($responsible['last_names']))).'<br /><br />';
				        			}
				        		?>
				        	</td>
				        </tr>
				    <?php
				    	$i++; 
				    	endforeach; ?>
				</table>
	        <?php else: ?>
	        	<div class="alert alert-danger">
	        		Esta Planificación Anual, no tienen metas registradas o asociadas a el.
	        	</div>
	        <?php endif;
	    ?>
    </div>
</div>