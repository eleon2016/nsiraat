<script src="../../js/planning/planning.js"></script>
<div class="container" id="ContainerTime" style="display: none;">
  <div class="row">
    <div class="col-md-12"><br /><br />      
      <div class="panel panel-default shadow-z-1">
        <div class="panel-body">
          <div class="page-header">
            <h3><img src="../../api/images/planner.png" width="32" height="32"> Planificación</h3>
            <span class="text-muted small">
                Este módulo contienen todas las herramientas necesarias para construir sus planificaciones, anuales
                y/o mensuales. No debe preocuparse si no puede terminar su trabajo en una sola sesión, puede guardar
                sus cambios y volver luego a terminarla.
            </span>
          </div>
          
          <div class="row">
            <br />
            <div class="col-md-12">
              
              <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                <li class="active">
                  <a href="#AnualPlanner" data-toggle="tab">
                    <span  class="glyphicon glyphicon-calendar"></span>
                    Planificación anual
                  </a>
                </li>
                <li>
                  <a href="#MounthPlanner" data-toggle="tab">
                    <span  class="glyphicon glyphicon-th"></span>
                    Planificación mensual
                  </a>
                </li>
              </ul>
              
              <div id="my-tab-content" class="tab-content">
                <div class="tab-pane active" id="AnualPlanner">
                  <br />
                  <div class="row">
                      <div class="col-md-2">
                        <?php if( $_SESSION['SessionPrivilegy'] == 'administrador' ): ?>
                          <button type="button" class="btn btn-primary btn-block shadow-z-1" id="MakePlan">
                            <span  class="glyphicon glyphicon-file"></span> Construir nuevo
                          </button>
                        <?php endif; ?>
                        <button type="button" class="btn btn-primary btn-block shadow-z-1" id="ListPlan">
                          <span  class="glyphicon glyphicon-list"></span> Listar existentes
                        </button>
                      </div>
                      
                      <div class="col-md-10">
                        <?php if( $_SESSION['SessionPrivilegy'] == 'administrador' ): ?>
                            <div id="divFormsMakePlanner"></div>
                        <?php else: ?>
                            <div id="divFormsListPlanner"></div>
                        <?php endif; ?>
                      </div>
                  </div>
                  
                </div>
    
                <div class="tab-pane" id="MounthPlanner">
                  <!--<h1>Planificación mensual</h1>-->
                  <!--<p>orange orange orange orange orange</p>-->
                </div>
                
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
