<?php 
session_start(); 
$id_plan = $_POST['IdPlan'];
include '../../../controller/planning/PlanningController.php';
?>

<div class="row">
    <div class="col-md-12">
        Plan Operativo Anual<br />
        <span style="font-size: 24px; font-weight: bold;" class="text-primary">
            <?php
                $name_plan = new PlanningController();
                $n_name =  $name_plan->GetAnualPLanNameById( $id_plan );
                echo trim(utf8_decode(ucwords( $n_name[0] )));
            ?>
        </span>
        <input type="hidden" id="IdCenter" value="<?php echo $n_name[1]; ?>">
        <div class="alert alert-warning" id="alert">
            <small>Sólo cuando esté seguro de haber culminado la construcción de su P.O.A, haga clic en
            <strong>"Terminar/cerrar edición"</strong>. Esto establecerá a este P.O.A. como el vigente y toda su
            planificación estará sujeta a él.<br /><br />
            <span class="text-danger"><strong>Este Proceso es irreversible.</strong></span></small>
        </div>
    </div>
</div>
<br />
<div class="row">
    <div class="col-md-12">
        <div class="well">
            <div class="row">
                <div class="col-md-4">
                    <a href="http://www.eduteka.org/pdfdir/TaxonomiaBloomCuadro.pdf" target="_blank" class="btn btn-info btn-block shadow-z-1">
                        <span class="glyphicon glyphicon-globe"></span> Taxonomía de Bloom
                    </a>
                    
                </div>
                <div class="col-md-4">
                    <a href="http://es.wikihow.com/establecer-metas" target="_blank" class="btn btn-info btn-block shadow-z-1">
                        <span class="glyphicon glyphicon-globe"></span> ¿Cómo construir metas?
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="http://www.organizartemagazine.com/7-pasos-para-elaborar-tu-cronograma-de-actividades/" target="_blank" class="btn btn-info btn-block shadow-z-1">
                        <span class="glyphicon glyphicon-globe"></span> ¿Cómo establecer actividades?
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12" style="border-bottom: 1px solid; border-bottom-color: #DBDBDB;">
        <strong><span class="glyphicon glyphicon-tags"> </span> Detalles del Plan Operativo Anual</strong>
</div>
<br /><br />
<form id="FormDetailsNewPOA" method="post">
    <div class="row">
        <div class="col-md-12">
            <div class="alert" id="DivAlertSave" style="display:none;"></div>
        </div>
    </div>
    <input type="hidden" id="IdPlan" value="<?php echo $_POST['IdPlan']; ?>">
    <div class="row">
        <div class="col-md-6">
            Meta
            <textarea class="form-control" rows=3 id="Goal" required></textarea>
        </div>
        <div class="col-md-6">
            Desafíos de la calidad educativa <small class="text-muted"><i>(Presione ctrl+clic para seleccionar varios)</i></small>
            <?php
                include '../../../controller/challenges/ChallengesController.php';
                $data_list = new ChallengesController();
                $request_data= $data_list->ListAllChallenges();
            ?>
            <select class="form-control" id="SelectChallenges" multiple required>
                <?php foreach($request_data as $data): ?>
                <option value="<?php echo $data['idChallenge']; ?>"><?php echo utf8_decode(trim(ucfirst($data['challenge']))); ?></option>
                <?php endforeach ?>
            </select>
        </div>
    </div>
    
    <br />
    <div class="row">
        <div class="col-md-6">
            Actividades 
            <textarea class="form-control" rows=3 id="Activities" required></textarea>
        </div>
        <div class="col-md-6">
            Indicadores
            <textarea class="form-control" rows=3 id="Indicators" required></textarea>
        </div>
    </div>
    
    <br />
    <div class="row">
        <div class="col-md-6">
            Meses <small class="text-muted"><i>(Presione ctrl+clic para seleccionar varios)</i></small>
            <select class="form-control" multiple id="Mounths" required>
                <option value="enero">Enero</option>
                <option value="febrero">Febrero</option>
                <option value="marzo">Marzo</option>
                <option value="abril">Abril</option>
                <option value="mayo">Mayo</option>
                <option value="junio">Junio</option>
                <option value="julio">Julio</option>
                <option value="agosto">Agosto</option>
                <option value="septiembre">Septiembre</option>
                <option value="octubre">Octubre</option>
                <option value="noviembre">Noviembre</option>
                <option value="diciembre">Diciembre</option>
            </select>
        </div>
        <div class="col-md-6">
            Responsables <small class="text-muted"><i>(Presione ctrl+clic para seleccionar varios)</i></small>
            <?php
                include '../../../controller/personal/PersonalController.php';
                $data_personal = new PersonalController();
                $request_data_personal= $data_personal->getNamesPersonalByCenter( $_SESSION['SessionIdCenter'] );
            ?>
            <select class="form-control" id="SelectResponsibles" multiple required>
                <?php foreach($request_data_personal as $data_personal): ?>
                <option value="<?php echo $data_personal['IdPersonal']; ?>">
                    <?php echo utf8_decode(trim(ucwords($data_personal['names']))).' '.
                        utf8_decode(trim(ucwords($data_personal['last_names']))); ?>
                </option>
                <?php endforeach ?>
            </select>
        </div>
    </div>

    <br />
    <div class="row">
        <div class="col-md-6">
            Lugar:
            <input type="text" class="form-control" id="Place" required>
        </div>
    </div>

    <br />
    <div class="row">
        <div class="col-md-3">
            <button type="submit" class="btn btn-success btn-block shadow-z-1">
                <span class="glyphicon glyphicon-floppy-saved"></span> Guardar meta
            </button>
        </div>
        <div class="col-md-3">
            <button type="button" class="btn btn-default btn-block shadow-z-1" id="btnPreliminarView">
                <span class="glyphicon glyphicon-eye-close"></span> Vista preliminar
            </button>
        </div>
        <div class="col-md-3">
            <button type="button" class="btn btn-primary btn-block shadow-z-1" id="btnCloseEditionPlan">
                <span class="glyphicon glyphicon-folder-close"></span> Terminar/cerrar edición
            </button>
        </div>
        <div class="col-md-3">
            <button type="reset" class="btn btn-default btn-block shadow-z-1" id="btnCancel">
                <span class="glyphicon glyphicon-remove-sign"></span> Cancelar
            </button>
        </div>
    </div>
</form>