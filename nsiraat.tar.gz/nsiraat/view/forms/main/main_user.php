<script src="../../js/main/main.js"></script>
<div class="container" id="ContainerPrimary" style="display: none;">
  <div class="row">
    <div class="col-md-12"><br /><br />
      <!--<div class="page-header">-->
      <!--  <h3>Módulos del usuario</h3>-->
      <!--</div>-->
      <div class="panel panel-default shadow-z-1">
        <div class="panel-body">
          <div class="page-header">
            <h3>Módulos disponibles <span class="text-muted small">(Solo seleccione la opción que desée trabajar)</span></h3>
          </div>
          
          <div class="row">
            
            <div class="col-md-3">
              <div style="text-align: center; margin-bottom: 10px;">
                <img src="../../api/images/check-hour.png">
              </div>
              <button type="button" class="btn btn-primary btn-block shadow-z-1" id="Assistance">Asistencias</button>
            </div>
            
            <div class="col-md-3">
               <div style="text-align: center; margin-bottom: 10px;">
                <img src="../../api/images/store.png">
              </div>
              <button type="button" class="btn btn-primary btn-block shadow-z-1">Inventarios</button>
            </div>
            
            <div class="col-md-3">
              <div style="text-align: center; margin-bottom: 10px;">
                <img src="../../api/images/planner.png">
              </div>
              <button type="button" class="btn btn-primary btn-block shadow-z-1" id="Planning">Planificación</button>
            </div>
            
            <div class="col-md-3">
              <div style="text-align: center; margin-bottom: 10px;">
                <img src="../../api/images/kblogger.png">
              </div>
              <button type="button" class="btn btn-primary btn-block shadow-z-1">Difusiones</button>
            </div>
            
          </div>
          <br />
          <div class="row">
            
            <div class="col-md-3">
              <div style="text-align: center; margin-bottom: 10px;">
                <img src="../../api/images/preference.png">
              </div>
              <button type="button" class="btn btn-primary btn-block shadow-z-1">Preferencias de la cuenta</button>
            </div>
          </div>
        
        </div>
      </div>
    </div>
  </div>
</div>