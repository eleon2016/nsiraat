<script src="../../js/userNoAssoc.js"></script>
<div class="container">
  <div class="row" id="divPrimary">
    <div class="col-md-12">
      <div class="page-header">
        <h2>Su cuenta aún no está asociada a un centro informático.</h2>
      </div>
      <div class="panel panel-default shadow-z-1">
        <div class="panel-body">
          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-info shadow-z-1">
                <p>
                  Bienvenido(a), esta es la primera vez que ingresa a SIRAAT, es necesario asociar su usuario:
                  <strong><?php echo $_SESSION['SessionUser']; ?></strong> al centro informático en el cual cumple sus
                  funciones. Esta petición se realizará sólo esta vez y de ella queda sujeta todas sus sesiones de
                  trabajo en SIRAAT.
                </p>
                <p>
                  NOTA: si por alguna razón se ha equivocado en la selección del centro informático, debe usted comunicarse
                  con el administrador del sistema y notificar la irregularidad; su cuenta de usuario no está autorizada
                  para realizar cambios en esta configuración.
                </p>
              </div>
            </div>
          </div>
          
          <div class="row">
            <form id="frmAssocAccount">
              <div class="col-md-8">
                Seleccione su centro informático:
                <?php
                    include '../../controller/centers/CentersController.php';
                    $centers = new CentersController();
                    $datas = $centers->getAllCenters();
                ?>
                <select class="form-control" id="selectCenters">
                  <?php foreach( $datas as $data ): ?>
                    <option value="<?= $data['IdCenter']; ?>"><?= ucwords(utf8_decode($data['center_name'])); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-4">
                <br />
                <button type="submit" class="btn btn-primary shadow-z-1">Asociar cuenta</button>
                <button type="button" class="btn btn-default shadow-z-1" onclick="CancelAssoc();">Cancelar</button>
              </div>
            </form>
          </div>
          
        </div>
      </div>
    </div>
  </div>
  
  <div class="row" id="divSecundary" style="display: none;">
    <div class="col-md-12">
      <div class="page-header">
        <!--<h2><strong>Cuenta asociada</strong></h2>-->
      </div>
      <div class="panel panel-default shadow-z-1">
        <div class="panel-body">
          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-success shadow-z-1">
                <strong><h3>Su cuenta fue asociada correctamente</h3></strong>
                Por favor, cierre su sesión actual e inicie nuevamente para validar su configuración reciente.
                <br /><br />
                <button type="button" class="btn btn-success shadow-z-1" onclick="CancelAssoc();">Cerrar sesión</button>
              </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</div>

</div>