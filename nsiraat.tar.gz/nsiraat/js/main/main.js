$(function () {
    $('#ContainerPrimary').fadeIn(1000);
    
    $('#Assistance').click(function(){ $(location).attr('href','../assistance'); });
    $('#Planning').click(function(){ $(location).attr('href','../planning'); });
});