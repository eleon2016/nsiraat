function CloseSession()
{
    if (confirm("¿Está seguro de cerrar la sesión?")) {
        window.location="../../php/CloseSession.php";
    }
}

function CancelAssoc()
{
    window.location="../../php/CloseSession.php";
}