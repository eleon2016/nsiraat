$(function () {
    $("#frmAssocAccount").submit(function(event){
        var data = {
            'center' : $("#selectCenters").val()
        };
        $.ajax({
            data: data,
            url: "../../php/assocUserCenter.php",
            type: 'post',
            dataType: 'html',
            beforeSend: function(){
                
            },
            success: function(ajaxResponse){
                if (ajaxResponse == 'success') {
                    $('#divPrimary').slideUp(500, function(){
                        $('#divSecundary').slideDown(500);
                    });
                    
                }
            }
        });
        event.preventDefault();
    });
});
