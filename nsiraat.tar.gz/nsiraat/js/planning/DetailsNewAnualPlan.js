$(function(){

	$('#alert').delay(7000).slideUp('slow');
	
	//Evento submit del formulario de registro de metas
	//es invocado en la creación de POA desde los detalles.
    $('#FormDetailsNewPOA').submit(function(event)
    {
		var Goal = $('#Goal').val();
		var IdPlan = $('#IdPlan').val();
		var Challenges = $( "#SelectChallenges" ).val();


		var Activities = $( "#Activities" ).val();
        Activities = Activities.replace(/\r?\n/g, '-');

        var Indicators = $( "#Indicators" ).val();
        Indicators = Indicators.replace(/\r?\n/g, '-');

        var Mounths = $( "#Mounths" ).val();
        var Responsibles = $( "#SelectResponsibles" ).val();
        var Place = $( "#Place" ).val();

        var data = {
        	'IdPlan': IdPlan, 
        	'Goal': Goal,
        	'Challenges': Challenges,
        	'Activities': Activities,
        	'Indicators': Indicators,
        	'Mounths': Mounths,
        	'Responsibles': Responsibles,
            'Place': Place,
            'Orige': 'Planificada',
            'method': 'SaveDetailsNewPlan'
        };
        $.ajax({
            data: data,
            url: 'rPlanning.php',
            type: 'post',
            dataType: 'json',
            beforSend: function(){

            },
            success: function( ajaxResponse ){
                if (ajaxResponse.Status == 'Success') {
                    $('#DivAlertSave').addClass('alert-success');
                    $('#DivAlertSave').html('Meta registrada correctamente');
                    $('#DivAlertSave').slideDown('slow').delay(2000).slideUp('slow');
                    $('#btnCancel').click();
                    $('#Goal').focus();
                };
            }
        });

		event.preventDefault();
	});

    $('#btnPreliminarView').click(function () {
        var IdPlan = $('#IdPlan').val();
        $.post('../../view/forms/planning/poa_preliminar_view.php', {IdPlan:IdPlan}, function(page){
            $("#divFormsMakePlanner").html(page);
            $.getScript('../../js/planning/DetailsNewAnualPlan.js');
        });
    })

    $('#btnEditionBack').click(function () {
        var IdPlan = $('#IdPlan').val();
        $("#divFormsMakePlanner").empty();
        $.post('../../view/forms/planning/details_new_anual_plan.php', {IdPlan:IdPlan}, function(page){
            $("#divFormsMakePlanner").html(page);
            $.getScript('../../js/planning/DetailsNewAnualPlan.js');
        });
    });

    $('#btnCloseEditionPlan').click(function () {
        var IdPlan = $('#IdPlan').val();
        var IdCenter = $('#IdCenter').val();
        var data = {
            'IdPlan': IdPlan,
            'IdCenter': IdCenter,
            'method': 'CloseEditionPlan'
        };
        $.ajax({
            data: data,
            url: '../../php/rPlanning.php',
            type: 'post',
            dataType: 'json',
            beforSend: function(){

            },
            success: function (ajaxResponse) {
                if(ajaxResponse.Status == 'Update'){
                    $.post('../../view/forms/planning/list_all_anual_plan_by_center.php',function(page){
                        $("#divFormsMakePlanner").html(page);
                        $.getScript('../../js/planning/MakeNewAnualPlan.js');
                    });
                }
            }
        });
    });
});