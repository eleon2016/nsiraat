$(function () {
    
    $('#NewAnualPlanName').focus();

    $('#FormMakeNewAnualPlan').submit(function(event)
    {
        var PlanName = $('#NewAnualPlanName').val();
        var DefaultPlan = $('#CheckDefault').val();
        var data = {
            'PlanName' : PlanName,
            'DefaultPlan': DefaultPlan,
            'method' : 'MakeNewAnualPlan'
        };
        $.ajax({
            data: data,
            url: "../../php/rPlanning.php",
            type: 'post',
            dataType: 'json',
            beforeSend: function(){
                
            },
            success: function(ajaxResponse){
                if (ajaxResponse.Status == 'Success') {
                    $.post('../../view/forms/planning/details_new_anual_plan.php',
                          {IdPlan:ajaxResponse.last_id, PlanName:ajaxResponse.name}, function(page){
                        $("#divFormsMakePlanner").html(page);
                        $.getScript('../../js/planning/DetailsNewAnualPlan.js');
                    });
                }else{
                    $('#MessageIsset').fadeIn('slow').delay(3000).fadeOut('slow');
                }
            }
        });
        event.preventDefault();
    });

    $('#bttViewList').click(function(){
        var IdCenter = $('#SelectCenter').val();
        ViewListAllAnualPanByCenter( IdCenter );
    });
        
});

function ViewListAllAnualPanByCenter (IdCenter) {
    $.post('../../view/forms/planning/view_list_all_anual_plan_by_center.php',{IdCenter:IdCenter}, function(page){
        $("#DivListAllPlanByCenter").html(page);
        $.getScript('../../js/planning/DetailsNewAnualPlan.js');
    });
}

function ViewPlan(IdPlan){
    $("#divFormsMakePlanner").empty();
    $.post('../../view/forms/planning/poa_preliminar_view.php', {IdPlan:IdPlan}, function(page){
        $("#divFormsMakePlanner").html(page);
        $("#divFormsListPlanner").html(page);
        $.getScript('../../js/planning/DetailsNewAnualPlan.js');
    });
}

function EditPlan(IdPlan){
    $("#divFormsMakePlanner").empty();
    $.post('../../view/forms/planning/details_new_anual_plan.php', {IdPlan:IdPlan}, function(page){
        $("#divFormsMakePlanner").html(page);
        $("#divFormsListPlanner").html(page);
        $.getScript('../../js/planning/DetailsNewAnualPlan.js');
    });
}

function DeleteAnualPlan(IdPlan) {
    if(confirm("El P.O.A. junto con los elementos relacionados a él, serán eliminados de forma permanente.\n\n¿Desea contiunuar?"))
    {
        var data = {
            'IdPlan': IdPlan,
            'method': 'DeleteAnualPlan'
        };
        $.ajax({
            data: data,
            url: '../../php/rPlanning.php',
            type: 'post',
            dataType: 'json',
            beforeSend: function(){

            },
            success: function(ajaxResponse){
                if(ajaxResponse.status == 'Ok'){
                    $('#DivAlertDeletePOA').slideDown('slow').delay(2000).slideUp('slow', function(){
                        $('#ListPlan').click();
                    });
                }else{
                    alert('no se elimino');
                }
            }
        });
    }
}

function DownloadPlan (IdPlan) {
    var data = { 'IdPlan': IdPlan, 'method': 'ExportPOAPdf'};
    $.ajax({
        data: data,
        url: '../../php/rPlanning.php',
        type: 'post',
        dataType: 'html',
        beforSend: function () {

        },
        success: function (ajaxResponse) {
            // body...
        }
    });
}