$(function () {
    $('#ContainerTime').fadeIn(1000);
    $('#tabs').tab();
    
    $.post('../../view/forms/planning/make_new_anual_plan.php',function(page){
        $("#divFormsMakePlanner").html(page);
        $.getScript('../../js/planning/MakeNewAnualPlan.js');
    });
    $.post('../../view/forms/planning/list_all_anual_plan_by_center.php',function(page){
        $("#divFormsListPlanner").html(page);
        $.getScript('../../js/planning/MakeNewAnualPlan.js');
    });

    /*$('#divFormsMakePlanner').load('../../view/forms/planning/make_new_anual_plan.php');
    $.getScript('../../js/planning/MakeNewAnualPlan.js');*/

    /*$('#divFormsListPlanner').load('../../view/forms/planning/list_all_anual_plan_by_center.php');
    $.getScript('../../js/planning/MakeNewAnualPlan.js');*/
    
    $('#MakePlan').click(function(){        
        $('#divFormsMakePlanner').load('../../view/forms/planning/make_new_anual_plan.php');
        $.getScript('../../js/planning/MakeNewAnualPlan.js');
    });

    $('#ListPlan').click(function(){
    	$.post('../../view/forms/planning/list_all_anual_plan_by_center.php',function(page){
    		$("#divFormsMakePlanner").html(page);
            $("#divFormsListPlanner").html(page);
            $.getScript('../../js/planning/MakeNewAnualPlan.js');
    	});
    });
});