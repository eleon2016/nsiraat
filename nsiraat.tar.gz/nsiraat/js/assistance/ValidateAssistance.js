$(function () {
    
    $('#SelectCenter').change(function(){
        var IdSelectCenter =  $('#SelectCenter').val();
        $.get('../../view/forms/assistance/view_personal_by_center.php', {IdCenter: IdSelectCenter}, function(page){
            $("#DivSelectSelectPersonal").html(page);
            $.getScript('../../js/assistance/ValidateAssistance.js')
    	});
    });
    
    $("#formSelectPersonal").submit(function(event){
        var IdSelectPersonal =  $('#SelectPersonal').val();
        $.get('../../view/forms/assistance/list_assistance_no_validate.php', {IdPersonal: IdSelectPersonal}, function(page){
            $("#DivViewListAssitanceNoValidate").html(page);
            $.getScript('../../js/assistance/ValidateAssistance.js')
    	});
        
        event.preventDefault();
    });
        
});

function ValidateAssistance( IdAssistance, IdPersonal ){
    var data = {
        'IdAssistance' : IdAssistance,
        'IdPersonal' : IdPersonal,
        'method' : 'ValidateAssistance'
    };
    $.ajax({
        data: data,
        url: "rAssistance.php",
        type: 'post',
        dataType: 'html',
        beforeSend: function(){
                
        },
        success: function(ajaxResponse){
            if (ajaxResponse == 'Success') {
                $.get('../../view/forms/assistance/list_assistance_no_validate.php', {IdPersonal: IdPersonal}, function(page){
                    $("#DivViewListAssitanceNoValidate").html(page);
                    $.getScript('../../js/assistance/ValidateAssistance.js');
                });
            }else{
                alert('Ocurrió un error');
            }
        }
    });
}

function ViewFormInvalidateAssistance( IdAssistance, IdPersonal )
{
    $.get('../../view/forms/assistance/invalidate_assistance.php',{IdAssistance:IdAssistance, IdPersonal:IdPersonal}, function(page){
        $("#DivViewListAssitanceNoValidate").html(page);
        $.getScript('../../js/assistance/ValidateAssistance.js');
    });
    
}

$("#formInvalidateAssistance").submit(function(event)
{
    var IdPers = $('#IdPersonal').val();
    var data = {
        'IdAssistance' : $('#IdAssistance').val(),
        'IdPersonal' : $('#IdPersonal').val(),
        'Observations': $('#txtObservations').val(),
        'method' : 'InValidateAssistance'
    };
    $.ajax({
        data: data,
        url: "rAssistance.php",
        type: 'post',
        dataType: 'html',
        beforeSend: function(){
                
        },
        success: function(ajaxResponse){
            if (ajaxResponse == 'Success') {
                alert("El registro fue Invalidado");
                $.get('../../view/forms/assistance/list_assistance_no_validate.php', {IdPersonal: IdPers}, function(page){
                    $("#DivViewListAssitanceNoValidate").html(page);
                    $.getScript('../../js/assistance/ValidateAssistance.js');
                });
            }else{
                alert('Ocurrió un error');
            }
        }
    });
    
    event.preventDefault();
});

function CancelInvalidateAssistance(IdPers)
{
    $.get('../../view/forms/assistance/list_assistance_no_validate.php', {IdPersonal: IdPers}, function(page){
        $("#DivViewListAssitanceNoValidate").html(page);
        $.getScript('../../js/assistance/ValidateAssistance.js');
    });
}

function ViewFormJustifyAssistance( IdAssistance, IdPersonal )
{
    $.get('../../view/forms/assistance/justify_assistance.php',{IdAssistance:IdAssistance, IdPersonal:IdPersonal}, function(page){
        $("#DivViewListAssitanceNoValidate").html(page);
        $.getScript('../../js/assistance/ValidateAssistance.js');
    });
}

$("#formJustifyAssistance").submit(function(event)
{   
    var Cause = $('#txtJustifyCause').val();
    var Obs = $('#txtJustifyObs').val();
    var idAssistance = $('#IdAssistance').val();
    var idPersonal = $('#IdPersonal').val();
    
    var inputFileImage = document.getElementById('archivoImage');
    var file = inputFileImage.files[0];
    var data = new FormData();

    data.append('archivo',file);
    data.append('cause',Cause);
    data.append('obs',Obs);
    data.append('idAssistance',idAssistance);
    data.append('idPersonal',idPersonal);
    data.append('method','JustifyAssistance');
    $.ajax({
        url:'rAssistance.php',
        type:'post',
        dataType: 'json',
        contentType:false,
        data:data,
        processData:false,
        cache:false,
        beforeSend: function(){
            
        },
        success: function(ajaxResponse){
            if (ajaxResponse.status == 'fileError' ||
                ajaxResponse.status == 'nameDuplicate' ||
                ajaxResponse.status == 'upError' ||
                ajaxResponse.status == 'extError' ||
                ajaxResponse.status == 'sizeError' ) {
                $("#MessageUploadImage").fadeOut('slow', function(){
                    $("#Message").html(ajaxResponse.msg);
                    $(this).fadeIn('slow');
                });
            }else if (ajaxResponse.status == 'fileOk') {
                $.get('../../view/forms/assistance/list_assistance_no_validate.php', {IdPersonal: ajaxResponse.IdPersonal}, function(page){
                    $("#DivViewListAssitanceNoValidate").html(page);
                    $.getScript('../../js/assistance/ValidateAssistance.js')
                });
            }
        }
    });
    
    event.preventDefault();
});

function CancelJustifyAssistance(IdPers)
{
    $.get('../../view/forms/assistance/list_assistance_no_validate.php', {IdPersonal: IdPers}, function(page){
        $("#DivViewListAssitanceNoValidate").html(page);
        $.getScript('../../js/assistance/ValidateAssistance.js');
    });
}


