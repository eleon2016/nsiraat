$(function () {
    $("#formFindAssistanceBySelectCenter").submit(function(event){
        var IdCenter = $('#nIdcenter').val();
        
        $.get('../../view/forms/assistance/view_assistance_by_select_center.php', {IdCenter: IdCenter}, function(page){
            $("#DivViewList").html(page);
    	});
        
        event.preventDefault();
    });
    
    $("#formFindAssistanceByCenter").submit(function(event){
        $.get('../../view/forms/assistance/view_assistance_by_center.php', function(page){
            $("#DivViewList").html(page);
    	});
        
        event.preventDefault();
    });
});