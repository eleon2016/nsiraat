$(function () {
    $('#ContainerTime').fadeIn(1000);
    
    $('#FormTime').load('../../view/forms/assistance/mark_assistance.php');
    $.getScript('../../js/assistance/MarkAssistance.js');
    
    $('#Check').click(function(){
        $('#FormTime').load('../../view/forms/assistance/mark_assistance.php');
        $.getScript('../../js/assistance/MarkAssistance.js');
    });
    
    $('#List').click(function(){
        $('#FormTime').load('../../view/forms/assistance/list_assistance.php');
        $.getScript('../../js/assistance/ListAssistance.js');
    });
    
    $('#Valid').click(function(){
        $('#FormTime').load('../../view/forms/assistance/select_validate_assistance.php');
        $.getScript('../../js/assistance/ValidateAssistance.js');
    });
    
});