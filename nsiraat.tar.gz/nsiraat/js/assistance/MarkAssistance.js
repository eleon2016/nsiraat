$("#FormCheckTime").submit(function(event){
    var data = {
        'ci' : $("#txtCedNumber").val(),
        'method' : 'getNamesPersonalByCi'
    };
    $.ajax({
        data: data,
        url: "rAssistance.php",
        type: 'post',
        dataType: 'json',
        beforeSend: function(){
                
        },
        success: function(ajaxResponse){
            if (ajaxResponse.Status == 'Success') {
                var Id = ajaxResponse.Id;
                var Name = ajaxResponse.Name;
                var LastName = ajaxResponse.Last_Name;
                
                var data = {
                    'id' : Id,
                    'obs': $("#txtObs").val(),
                    'method' : 'MarkAssistance'
                };
                $.ajax({
                    data: data,
                    url: "rAssistance.php",
                    type: 'post',
                    dataType: 'json',
                    beforeSend: function(){
                            
                    },
                    success: function(ajaxResponse){
                        if (ajaxResponse.Status == 'Success') {
                            if(ajaxResponse.InOut == 'In')
                            {
                                $('#DivMessageHora').html('<span  class="glyphicon glyphicon-ok"></span> '+Name+' '+LastName+' su asistencia fue registrada correctamente<strong><br /> Hora de entrada: '+ajaxResponse.Hour+'</strong>');
                                $('#DivMessageHora').slideDown('slow').delay(5000).slideUp('slow');
                                $("#txtCedNumber").val('');
                                $("#txtObs").val('');
                                $("#txtCedNumber").focus();
                                
                            }else{
                                $('#DivMessageHora').html('<span  class="glyphicon glyphicon-ok"></span> '+Name+' '+LastName+' su asistencia fue registrada correctamente<strong><br /> Hora de salida: '+ajaxResponse.Hour+'</strong>');
                                $('#DivMessageHora').slideDown('slow').delay(5000).slideUp('slow');
                                $("#txtCedNumber").val('');
                                $("#txtObs").val('');
                                $("#txtCedNumber").focus();
                            }
                            
                        }else{
                            alert(ajaxResponse);
                            $('#DivMessage').removeClass('alert-success');
                            $('#DivMessage').addClass('alert-danger');
                            $('#DivMessage').html('<strong>¡Error!</strong> Por hoy su asistencia ya fue registrada.');
                            $('#DivMessage').slideDown('slow').delay(3000).slideUp('slow');
                            $("#txtCedNumber").val('');
                            $("#txtObs").val('');
                            $("#txtCedNumber").focus();
                        }
                    }
                });
            }else{
                $('#DivMessage').removeClass('alert-success');
                $('#DivMessage').addClass('alert-danger');
                $('#DivMessage').html('<strong>¡Error!</strong> Cédula no registrada');
                $('#DivMessage').slideDown('slow').delay(3000).slideUp('slow');
                $("#txtCedNumber").val('');
                $("#txtObs").val('');
                $("#txtCedNumber").focus();
            }
        }
    });
    event.preventDefault();
});