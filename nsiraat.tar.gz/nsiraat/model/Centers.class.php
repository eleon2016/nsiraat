<?php
require_once 'conexMySQL.class.php';

class CentersModel extends ConexDataBase {
    
    private $sql;
    private $result;
    
    function __construct()
    {
        $this->sql = '';
        $this->result = '';
        $this->Conexion = new ConexDataBase();
    }
    
    public function getAllCenters()
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT IdCenter, center_name FROM centers ORDER BY center_name ASC";
            $this->result = mysql_query( $this->sql );
            for ($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;
        }
    }

    public function GetNameCenterById($id_center)
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT center_name FROM centers WHERE IdCenter='$id_center'";
            $this->result = mysql_query( $this->sql );
            return mysql_fetch_row($this->result);
            //for ($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            //return $set;
        }
    }
}