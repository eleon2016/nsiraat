<?php

require_once 'conexMySQL.class.php';

class Assistance extends ConexDataBase {
    
    private $sql;
    private $result;
    private $Conexion;
    
    function __construct()
    {
        $this->sql = '';
        $this->result = '';
        $this->Conexion = new ConexDataBase();
        ini_set('date.timezone', 'America/caracas');
    }
    
    
    public function MarkAssistance( $idPersonal, $idCenter, $obs )
    {
        $today = date('d/m/Y');
        $day =  date('d');
        $mounth =  date('m');
        $year =  date('Y');
        $hour = date('H:i:s');
        
        //Se verifica si el usuario ya ha marcado la asistencia del dia
        $check_today = $this->CheckAssistanceToday( $today, $idPersonal );
        
        //Si la respuesta es blanco, indica que el usuario no se ha registrado en el dia actual
        if( $check_today[1] != '' )
        {
            //De no ser blanco la respuesta, se verifica la hora de entrada
            //si es blanco, indica que no se ha marcado la asistencia, se marca la hora de entrada
            if($check_today[7] == ''){
                $rsp = $this->MarkAssistanceIn( $idPersonal, $idCenter, $today, $day, $mounth, $year, $hour, $obs );
                if($rsp != '') {
                    echo json_encode( array('Status'=>'Success', 'Hour'=>$hour, 'InOut'=>'In') );
                }else{
                    echo json_encode( array('Status'=>'Error', 'Hour'=>$resp, 'InOut'=>'In') );
                }
            }else{
                //si no es blanco, indica que ya marcó la entrada y ahora se debe marcar la hora de salida,
                $rsp = $this->MarkAssistanceOut( $idPersonal, $today, $hour, $obs );
                if($rsp != '') {
                    echo json_encode( array('Status'=>'Success', 'Hour'=>$hour, 'InOut'=>'Out') );
                }else{
                    echo json_encode( array('Status'=>'Error', 'Hour'=>$hour, 'InOut'=>'Out') );
                }
            }   
        }else{
            //Se marca la hora y fecha de ingreso
            $rsp = $this->MarkAssistanceIn( $idPersonal, $idCenter, $today, $day, $mounth, $year, $hour, $obs );
            if($rsp != '') {
                echo json_encode( array('Status'=>'Success', 'Hour'=>$hour, 'InOut'=>'In') );
            }
        }
        
    }
    
    
    private function CheckAssistanceToday( $today, $id )
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT *FROM assistance WHERE IdPersonal='$id' AND date='$today'";
            $this->result = mysql_query( $this->sql );
            return mysql_fetch_row( $this->result );
        }
    }
    
    private function MarkAssistanceIn( $idPersonal, $idCenter, $today, $day, $mounth, $year, $hour, $obs )
    {
        $this->sql = "INSERT INTO assistance (IdPersonal,IdCenter,date,day,mounth,year,hour_in,observation)
                    VALUES('$idPersonal','$idCenter','$today','$day','$mounth','$year','$hour','$obs')";
        mysql_query( $this->sql );
        $last_id = mysql_insert_id();
        
        $this->sql = "INSERT INTO validation_assistance (IdAssistance, validation) VALUES('$last_id','No validado')";
        return mysql_query( $this->sql );
    }
    
    private function MarkAssistanceOut( $idPersonal, $today, $hour, $obs )
    {
        $check = $this->CheckAssistanceToday( $today, $idPersonal );
        if($check[8] == '')
        {
            $this->sql = "UPDATE assistance SET hour_out='$hour', observation='$obs' WHERE IdPersonal='$idPersonal' AND date='$today'";
            return mysql_query( $this->sql );
        }else
            return '';
    }
    
    public function ListAssistanceToday( $center )
    {
        if( $this->Conexion->Connect() == true )
        {
            $today = date('d/m/Y');
            $this->sql = "SELECT a.*, b.ci, b.names, b.last_names, c.validation
                        FROM assistance a
                        JOIN personal b ON (a.IdPersonal = b.IdPersonal)
                        JOIN validation_assistance c ON (a.IdAssistance = c.IdAssistance)
                        WHERE a.Idcenter='$center' AND a.date='$today'";
            $this->result = mysql_query( $this->sql );
            for ($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;
        }
    }
    
    public function ListAssistanceNoValidateByPersonal( $idPersonal )
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT a.*, b.ci, b.names, b.last_names, c.validation, c.observation as obs_validate
                        FROM assistance a
                        JOIN personal b ON (a.IdPersonal = b.IdPersonal)
                        JOIN validation_assistance c ON (a.IdAssistance = c.IdAssistance)
                        WHERE a.IdPersonal='$idPersonal' AND c.validation='No Validado' ORDER BY a.date ASC";
            $this->result = mysql_query( $this->sql );
            for ($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;
        }
    }
    
    public function ValidateAssistance( $idAssistance, $idPersonal )
    {
        if( $this->Conexion->Connect() == true )
        {
            $valido = utf8_encode('Válido');
            $this->sql = "UPDATE validation_assistance SET validation='$valido', Idpersonal='$idPersonal' WHERE IdAssistance='$idAssistance'";
            if( mysql_query( $this->sql ) != '')
                return 'Success';
            else
                return 'Error';
        }
    }
    
    public function InvalidateAssistance( $idAssistance, $idPersonal, $obs )
    {
        if( $this->Conexion->Connect() == true )
        {
            $invalido = utf8_encode('Inválido');
            $this->sql = "UPDATE validation_assistance SET validation='$invalido', IdPersonal='$idPersonal', observation='$obs'
                            WHERE IdAssistance='$idAssistance'";
            if( mysql_query( $this->sql ) != '')
                return 'Success';
            else
                return 'Error';
        }
    }
    
    public function JustifyAssistence( $cause, $obs, $idAssistance, $idPersonal, $newName )
    {
        if( $this->Conexion->Connect() == true )
        {
            $Justify = utf8_encode('Justificado');
            $link = $newName.'.pdf';
            $this->sql = "UPDATE validation_assistance SET validation='$Justify', IdPersonal='$idPersonal', observation='$obs', link='$link'
                            WHERE IdAssistance='$idAssistance'";
            if( mysql_query( $this->sql ) != '')
                return json_encode( array('status'=>'fileOk', 'msg'=>'Justificación guardada','IdPersonal'=>$idPersonal) );
            else
                return json_encode( array('status'=>'fileUpError') );
        }
    }
}