<?php
/**
 *Clase que gestiona la conexión a la Base de Datos
 *Manejador de datos: PostgreSql
 */

class ConexDataBase {
    
    private $Host;
    private $Port;
    private $User;
    private $Passwd;
    private $DB;
    private $Param;
    
    function __construct()
    {
        $this->Host = 'localhost';
        $this->Port = '5432';
        $this->User = 'postgres';
        $this->Passwd = 'postgres';
        $this->DB = 'nsiraat';
        $this->Param = "host=$this->Host dbname=$this->DB user=$this->User password=$this->Passwd port=$this->Port";
    }
    
    /**
     *Método Coonect
     *Establece la conexión con PostgreSql
     */
    public function Connect()
    {
        if ( !isset($this->conexion) )
        {
            $this->__construct();
            $this->conexion = pg_connect( $this->Param );
            if( $this->conexion )
                return true;
            else
                return false;
        }
    }
    
    /**
     *Método DisConnect
     *Cierra la conexión actual a PostgreSql
     */
    public function DisConnect()
    {
        pg_close( $this->conexion );
    }

}