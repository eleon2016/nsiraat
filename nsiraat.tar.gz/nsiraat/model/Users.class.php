<?php

/**
 *Esta clase gestiona todas la operaciones relacionadas con los
 *usuarios del sistema.
 */
//include '../api/php/constants.php';
include 'conexMySQL.class.php';

class Users extends ConexDataBase {
    private $UserName;
    private $Password;
    private $sql;
    private $result;
    
    function __construct($user,$password)
    {
        $this->UserName = $user;
        $this->Password = $password;
        $this->sql = '';
        $this->result = '';
        $this->Conexion = new ConexDataBase();
    }
    
    /**
     *Método ValidateUsers
     *Verifica que las credenciales suministradas por un usuario, estén registradas en
     *la base de datos y sean usuarios legítimos del sistema.
     */
    public function ValidateUsers()
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT a.IdUA,a.user,b.privilegy
                FROM user_account a
                JOIN privilegy b ON ( a.IdPrivilegy = b.IdPrivilegy )
                WHERE user='$this->UserName' AND password='$this->Password'";
            $this->result = mysql_query( $this->sql );
            return mysql_fetch_row( $this->result );
        }
    }
    
    
    public function getRelationUserCenter( $idUser )
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT idCenter FROM rel_user_center WHERE idUser='$idUser'";
            $this->result = mysql_query( $this->sql );
            return mysql_fetch_row( $this->result );
        } 
    }
    
    public function AssocUserCenter( $idUser,$idCenter)
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "INSERT INTO rel_user_center(idUser, idCenter) VALUES('$idUser','$idCenter')";
            $this->result = mysql_query( $this->sql );
            return 'success';
        }
    }
}
