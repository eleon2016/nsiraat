<?php

require_once 'conexMySQL.class.php';

class Planning extends ConexDataBase
{
    protected $sql;
    protected $result;
    protected $conexion;
    
    function __construct()
    {
        $this->sql = '';
        $this->result = '';
        $this->conexion = new ConexDataBase();
        ini_set('date.timezone', 'America/caracas');
    }
    
    public function MakeNewAnualPLan( $plan_name, $plan_default, $id_center, $edition_status )
    {
        if( $this->conexion->Connect() == true )
        {
            $this->sql = "SELECT *FROM planner WHERE plan_name='$plan_name'";
            $this->result = mysql_query( $this->sql );
            if( mysql_fetch_row( $this->result )!= 0 ) 
            {
                return json_encode( array('Status'=>'Fail') );
            }else{
                $last_id = $this->RegisterNewNamePlan( $plan_name, $id_center, $edition_status );
                return  json_encode( array('Status'=>'Success', 'name'=>$plan_name, 'last_id'=>$last_id) );
            }
        }
    }
    
    private function RegisterNewNamePlan( $plan_name, $id_center, $edition_status )
    {
        $today = date('d/m/Y');
        $year =  date('Y');
        $n_plan_name = trim(strtolower(utf8_encode($plan_name)));
        $this->sql = "INSERT INTO planner(idCenter, plan_name, plan_date, plan_year, edition_status)
                        VALUES('$id_center','$n_plan_name','$today','$year','$edition_status')";
        mysql_query( $this->sql );
        return mysql_insert_id();
    }

    public function SaveDetailsNewPlan($id_plan, $goals, $challenges, $activities, $indicators, $mounths, $responsibles, $place, $orige)
    {
        if( $this->conexion->Connect() == true )
        {
            $n_goals = trim(strtolower(utf8_encode($goals)));
            $n_place = trim(strtolower(utf8_encode($place)));
            $this->sql = "INSERT INTO goals(idPlan,goal,place,orige) VALUES('$id_plan','$n_goals','$n_place', '$orige')";
            if( mysql_query( $this->sql ) != '')
            {
                $last_id = mysql_insert_id();
                $this->AsociateChallenger($last_id, $challenges);
                $this->AsociateActivities($last_id, $activities);
                $this->AsociateIndicators($last_id, $indicators);
                $this->AsociateMounths($last_id, $mounths);
                $this->AsociateResponsibles($last_id, $responsibles);
                return json_encode(array('Status'=>'Success'));
            }else
                return json_encode(array('Status'=>'Error'));
        }
    }

    private function AsociateChallenger($id_goal, $challenges)
    {
        $n_challenges = '';
        for($i=0; $i<count($challenges); $i++)
        {
            $n_challenge = $challenges[$i];
            $this->sql = "INSERT INTO associate_challenger(IdGoal,IdChallenge) VALUES('$id_goal','$n_challenge')";
            mysql_query($this->sql);
        }
    }
    private function AsociateActivities($id_goal, $activities)
    {
        $n_activities = '';
        $activities = explode('-',$activities);
        for($i=0; $i<count($activities); $i++)
        {
            $n_activities = trim(strtolower(utf8_encode($activities[$i])));
            $this->sql = "INSERT INTO associate_activities(IdGoal,activitie) VALUES('$id_goal','$n_activities')";
            mysql_query($this->sql);
        }
    }
    private function AsociateIndicators($id_goal, $indicators)
    {
        $n_indicators = '';
        $indicators = explode('-',$indicators);
        for($i=0; $i<count($indicators); $i++)
        {
            $n_indicators = trim(strtolower(utf8_encode($indicators[$i])));
            $this->sql = "INSERT INTO associate_indicators(IdGoal,indicator) VALUES('$id_goal','$n_indicators')";
            mysql_query($this->sql);
        }
    }
    private function AsociateMounths($id_goal, $mounths)
    {
        $n_mounths = '';
        for($i=0; $i<count($mounths); $i++)
        {
            $n_mounth = $mounths[$i];
            $this->sql = "INSERT INTO associate_mounths(IdGoal,mounth) VALUES('$id_goal','$n_mounth')";
            mysql_query($this->sql);
        }
    }
    private function AsociateResponsibles($id_goal, $responsibles)
    {
        $n_responsibles = '';
        for($i=0; $i<count($responsibles); $i++)
        {
            $n_responsible = $responsibles[$i];
            $this->sql = "INSERT INTO associate_responsibles(IdGoal,IdPersonal) VALUES('$id_goal','$n_responsible')";
            mysql_query($this->sql);
        }
    }

    public function GetAnualPLanNameById($id_plan)
    {
        if ($this->conexion->Connect() == true)
        {
            $this->sql = "SELECT plan_name,idCenter,edition_status,plan_date FROM planner WHERE IdPlan='$id_plan'";
            $this->result = mysql_query($this->sql);
            return mysql_fetch_row($this->result);
        }
    }

    public function ListAnualPlanByCenter($id_center)
    {
        if($this->conexion->Connect() == true )
        {
            $this->sql = "SELECT *FROM planner WHERE idCenter='$id_center' ORDER BY plan_date ASC";
            $this->result = mysql_query( $this->sql );
            for($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;
        }
    }

    public function GetGoalsByIdPLan($id_plan)
    {
        if($this->conexion->Connect() == true)
        {
            $this->sql = "SELECT *FROM goals WHERE IdPlan='$id_plan'";
            $this->result = mysql_query($this->sql);
            for($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;
        }
    }

    public function GetChallengesByIdGoal($id_goal)
    {
        if ($this->conexion->Connect() == true) {
            $this->sql = "SELECT b.IdChallenge, b.challenge
                            FROM associate_challenger a
                            JOIN challenges b ON( a.IdChallenge = b.IdChallenge)
                            WHERE IdGoal='$id_goal'";
            $this->result = mysql_query($this->sql);
            for($set=array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;            
        }
    }

    public function GetActivitiesByIdGoal($id_goal)
    {
        if($this->conexion->Connect() == true)
        {
            $this->sql = "SELECT activitie FROM associate_activities WHERE IdGoal='$id_goal'";
            $this->result = mysql_query($this->sql);
            for($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row );
            return $set;
        }
    }

    public function GetIndicatorsByIdGoal($id_goal)
    {
        if($this->conexion->Connect() == true)
        {
            $this->sql = "SELECT indicator FROM associate_indicators WHERE IdGoal='$id_goal'";
            $this->result = mysql_query($this->sql);
            for($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row );
            return $set;
        }
    }

    public function GetMounthsByIdGoal($id_goal)
    {
        if($this->conexion->Connect() == true)
        {
            $this->sql = "SELECT mounth FROM associate_mounths WHERE IdGoal='$id_goal'";
            $this->result = mysql_query($this->sql);
            for($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row );
            return $set;
        }
    }

    public function GetResponsiblesByIdGoal($id_goal)
    {
        if($this->conexion->Connect() == true)
        {
            $this->sql = "SELECT b.names,b.last_names
                            FROM associate_responsibles a
                            JOIN personal b ON( a.IdPersonal = b.IdPersonal)
                            WHERE IdGoal='$id_goal'";
            $this->result = mysql_query($this->sql);
            for($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row );
            return $set;
        }
    }

    public function DeleteAnualPlan($id_plan)
    {
        if($this->conexion->Connect() == true)
        {
            $this->sql = "DELETE FROM planner WHERE IdPlan='$id_plan'";
            $this->result = mysql_query($this->sql);
            if(mysql_affected_rows()>0)
                return json_encode(array('status'=>'Ok'));
            else
                return json_encode(array('status'=>'Fail'));
        }
    }

    public function CloseEditionPlan($id_plan, $id_center)
    {
        if($this->conexion->Connect() == true)
        {
            $this->sql = "SELECT *FROM default_center_plan WHERE idPlan='$id_Plan";
            $this->result = mysql_query($this->sql);
            if( mysql_affected_rows()>0 )
            {
                $this->sql = "UPDATE default_center_plan SET idPlan='$id_Plan', idCenter='$id_center'";
                $this->result = mysql_query($this->sql);
                if(mysql_affected_rows()>0)
                    return $this->UpdateEditionStatus($id_plan);
                    
            }else{
                $this->sql = "INSERT INTO default_center_plan(idPlan,idCenter) VALUES('$id_plan', '$id_center')";
                $this->result = mysql_query($this->sql);
                if(mysql_affected_rows()>0)
                    return $this->UpdateEditionStatus($id_plan);
            }
        }
    }

    private function UpdateEditionStatus($id_plan)
    {
        $this->sql = "UPDATE planner SET edition_status='close' WHERE idPlan='$id_plan'";
        $this->result = mysql_query($this->sql);
        if(mysql_affected_rows()>0)
            return json_encode(array('Status'=>'Update'));
    }
}