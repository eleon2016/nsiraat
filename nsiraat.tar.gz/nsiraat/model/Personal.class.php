<?php

require_once 'conexMySQL.class.php';

class PersonalModel extends ConexDataBase {

    private $sql;
    private $result;
    
    function __construct()
    {
        $this->sql = '';
        $this->result = '';
        $this->Conexion = new ConexDataBase();
    }
        
    public function getNamesPersonalByCi( $ci )
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT IdPersonal,names,last_names FROM personal WHERE ci='$ci'";
            $this->result = mysql_query( $this->sql );
            return mysql_fetch_row( $this->result ); 
        }
    }
    
    public function getNamesPersonalByCenter( $idCenter )
    {
        if( $this->Conexion->Connect() == true )
        {
            $this->sql = "SELECT IdPersonal,names,last_names FROM personal WHERE IdCenter='$idCenter'";
            $this->result = mysql_query( $this->sql );
            for ($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;
        }
    }
}
