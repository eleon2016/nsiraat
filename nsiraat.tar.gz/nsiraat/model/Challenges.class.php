<?php

require_once 'conexMySQL.class.php';

class Challenges extends ConexDataBase {
    
    protected $sql;
    protected $result;
    protected $conexion;
    
    function __construct()
    {
        $this->sql = '';
        $this->result = '';
        $this->conexion = new ConexDataBase();
    }
    
    public function ListAllChallenges()
    {
        if( $this->conexion->Connect() == true )
        {
            $this->sql = "SELECT *FROM challenges ORDER BY idChallenge ASC";
            $this->result = mysql_query( $this->sql );
            for ($set = array(); $row = mysql_fetch_assoc($this->result); $set[] = $row);
            return $set;
        }
    }
}