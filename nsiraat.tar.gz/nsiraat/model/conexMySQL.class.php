<?php

class ConexDataBase{
    protected $conexion;
    protected $db;
    
    function __construct()
    {
        //$this->host = 'http://db-server.czies.org.ve';
        $this->host = 'localhost';
        $this->user = 'root';
        $this->pass= '';
        //$this->pass = 'rootserv3r';
        $this->dbname = 'nsiraat';
    }
        
    function Connect()
    {
        $this->conexion = mysql_connect( $this->host, $this->user, $this->pass );
        if( $this->conexion == 0 ) exit();
        
        $this->db = mysql_select_db( $this->dbname, $this->conexion );
        if( $this->db == 0 ) exit();
        
        return true;
    }
    
    public function DisConnect()
    {
        mysql_close( $this->conexion );
    }
    
    /*public function pruebadb()
    {
        $tabla = "user_account";
        $query = mysql_query("SELECT count(*) from $tabla", $this->conexion);
        if ($query == 0) echo "Sentencia incorrecta llamado a tabla: $tabla.";
        else {
            $nregistrostotal = mysql_result($query, 0, 0);
            echo "Hay $nregistrostotal registros en la tabla: $tabla.";
            mysql_free_result($query);
        }
    }*/
}
/*
$db1 = new ConexDataBase();
if( $db1->Connect() ){
    $db1->pruebadb();
    $db1->DisConnect();
}*/
