-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 28-01-2016 a las 05:14:41
-- Versión del servidor: 5.6.26
-- Versión de PHP: 5.5.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `nsiraat`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `assistance`
--

CREATE TABLE IF NOT EXISTS `assistance` (
  `IdAssistance` int(11) NOT NULL,
  `IdPersonal` int(11) NOT NULL,
  `Idcenter` int(11) NOT NULL,
  `date` varchar(10) NOT NULL,
  `day` int(11) NOT NULL,
  `mounth` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `hour_in` varchar(8) NOT NULL,
  `hour_out` varchar(8) NOT NULL,
  `observation` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `assistance`
--

INSERT INTO `assistance` (`IdAssistance`, `IdPersonal`, `Idcenter`, `date`, `day`, `mounth`, `year`, `hour_in`, `hour_out`, `observation`) VALUES
(67, 1, 4, '10/01/2016', 0, 0, 0, '16:07:02', '16:11:03', ''),
(86, 1, 4, '13/01/2016', 13, 1, 2016, '15:15:02', '15:15:20', 'se fue la luz'),
(87, 1, 4, '14/01/2016', 14, 1, 2016, '20:44:25', '23:54:46', ''),
(88, 1, 4, '25/01/2016', 25, 1, 2016, '16:45:50', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `associate_activities`
--

CREATE TABLE IF NOT EXISTS `associate_activities` (
  `IdAssociateAct` int(11) NOT NULL,
  `IdGoal` int(11) NOT NULL,
  `activitie` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `associate_activities`
--

INSERT INTO `associate_activities` (`IdAssociateAct`, `IdGoal`, `activitie`) VALUES
(16, 29, 'actividad 1, esta es la primera que se realizarÃƒÂ¡ en la ejecuciÃƒÂ³n de las actividades.'),
(18, 29, 'actividad 2, esta es la segunda que se realizarÃƒÂ¡ en la ejecuciÃƒÂ³n de las actividades.'),
(20, 29, 'actividad 3, esta es la tercera que se realizarÃƒÂ¡ en la ejecuciÃƒÂ³n de las actividades.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `associate_challenger`
--

CREATE TABLE IF NOT EXISTS `associate_challenger` (
  `IdAssociateCha` int(11) NOT NULL,
  `IdGoal` int(11) NOT NULL,
  `IdChallenge` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `associate_challenger`
--

INSERT INTO `associate_challenger` (`IdAssociateCha`, `IdGoal`, `IdChallenge`) VALUES
(18, 29, 5),
(19, 29, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `associate_indicators`
--

CREATE TABLE IF NOT EXISTS `associate_indicators` (
  `IdAssociateInd` int(11) NOT NULL,
  `IdGoal` int(11) NOT NULL,
  `indicator` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `associate_indicators`
--

INSERT INTO `associate_indicators` (`IdAssociateInd`, `IdGoal`, `indicator`) VALUES
(15, 29, 'actividad 1, esta es la primera que se realizarÃƒÂ¡ en la ejecuciÃƒÂ³n de las actividades.'),
(21, 29, 'actividad 2, esta es la segunda que se realizarÃƒÂ¡ en la ejecuciÃƒÂ³n de las actividades.'),
(22, 29, 'actividad 3, esta es la segunda que se realizarÃƒÂ¡ en la ejecuciÃƒÂ³n de las actividades.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `associate_mounths`
--

CREATE TABLE IF NOT EXISTS `associate_mounths` (
  `IdassociateMounth` int(11) NOT NULL,
  `IdGoal` int(11) NOT NULL,
  `mounth` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `associate_mounths`
--

INSERT INTO `associate_mounths` (`IdassociateMounth`, `IdGoal`, `mounth`) VALUES
(13, 29, 'enero'),
(14, 29, 'febrero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `associate_responsibles`
--

CREATE TABLE IF NOT EXISTS `associate_responsibles` (
  `IdAssociateResp` int(11) NOT NULL,
  `IdGoal` int(11) NOT NULL,
  `IdPersonal` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `associate_responsibles`
--

INSERT INTO `associate_responsibles` (`IdAssociateResp`, `IdGoal`, `IdPersonal`) VALUES
(13, 29, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `centers`
--

CREATE TABLE IF NOT EXISTS `centers` (
  `IdCenter` int(11) NOT NULL,
  `center_name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `centers`
--

INSERT INTO `centers` (`IdCenter`, `center_name`) VALUES
(4, 'CBIT Golindano'),
(5, 'CBIT Araya'),
(6, 'CBIT Plan de la Mesa'),
(7, 'centro de producción de soluciones educativas tecnológicas del estado sucre (CPSET)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `challenges`
--

CREATE TABLE IF NOT EXISTS `challenges` (
  `idChallenge` int(11) NOT NULL,
  `challenge` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `challenges`
--

INSERT INTO `challenges` (`idChallenge`, `challenge`) VALUES
(1, 'garantizar educacion de calidad para todas y todos'),
(2, 'desarrollar una pedagogia del amor, el ejemplo y la curiosidad'),
(3, 'fortalecer el appel de los maestros y maestras como actores fundamentales de la calidad educativa'),
(4, 'promover un clima escolar caracterizado por la convivencia'),
(5, 'garantizar un sistema de proteccion estudiantil'),
(6, 'lograr una estrecha relacion entre las familias, la escuela y la comunidad'),
(7, 'desarrollar un curriculo nacional integrado y actualizado'),
(8, 'garantizar edificaciones educativas sencillas, amigables, seguras'),
(9, 'desarrollar un sistema de evaluacion de la calidad educativa'),
(10, 'reconfigurar la organización y funcionamiento del ministerio del poder popular para la educacion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `goals`
--

CREATE TABLE IF NOT EXISTS `goals` (
  `idGoal` int(11) NOT NULL,
  `idPlan` int(11) NOT NULL,
  `goal` text NOT NULL,
  `place` varchar(80) NOT NULL,
  `orige` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `goals`
--

INSERT INTO `goals` (`idGoal`, `idPlan`, `goal`, `place`, `orige`) VALUES
(29, 1, 'esa es la primera meta redactada de forma similar a una meta real de manera tal que parezca una real.', 'en un lugar de la mancha.', 'Planificada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

CREATE TABLE IF NOT EXISTS `personal` (
  `IdPersonal` int(11) NOT NULL,
  `ci` int(8) NOT NULL,
  `names` varchar(80) NOT NULL,
  `last_names` varchar(80) NOT NULL,
  `phone` int(11) NOT NULL,
  `IdCenter` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `personal`
--

INSERT INTO `personal` (`IdPersonal`, `ci`, `names`, `last_names`, `phone`, `IdCenter`) VALUES
(1, 13924912, 'eduardo rafael', 'leon brito', 2147483647, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planner`
--

CREATE TABLE IF NOT EXISTS `planner` (
  `idPlan` int(11) NOT NULL,
  `idCenter` int(11) NOT NULL,
  `plan_name` varchar(50) NOT NULL,
  `plan_date` varchar(10) NOT NULL,
  `plan_year` varchar(4) NOT NULL,
  `edition_status` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `planner`
--

INSERT INTO `planner` (`idPlan`, `idCenter`, `plan_name`, `plan_date`, `plan_year`, `edition_status`) VALUES
(1, 4, 'construir un nuevo plan operativo anual (p.o.a.)', '26/01/2016', '2016', 'abierto'),
(2, 4, '76', '26/01/2016', '2016', 'abierto'),
(3, 4, 'u', '26/01/2016', '2016', 'abierto'),
(4, 4, 'jhk', '26/01/2016', '2016', 'abierto'),
(5, 4, '6', '26/01/2016', '2016', 'abierto'),
(6, 4, 'hyu', '26/01/2016', '2016', 'abierto'),
(7, 4, '3', '26/01/2016', '2016', 'abierto'),
(8, 4, 'gh', '26/01/2016', '2016', 'abierto'),
(9, 4, 'r', '26/01/2016', '2016', 'abierto'),
(10, 4, 'rt', '26/01/2016', '2016', 'abierto'),
(11, 4, '8', '26/01/2016', '2016', 'abierto'),
(12, 4, 'ik', '26/01/2016', '2016', 'abierto'),
(13, 4, 'hj', '26/01/2016', '2016', 'abierto'),
(14, 4, 'uo', '26/01/2016', '2016', 'abierto'),
(15, 4, 't', '26/01/2016', '2016', 'abierto'),
(16, 4, 'ghr', '26/01/2016', '2016', 'abierto'),
(17, 4, 'ghjghj', '26/01/2016', '2016', 'abierto'),
(18, 4, 'dfgdf', '26/01/2016', '2016', 'abierto'),
(19, 4, 'vjmvbn', '26/01/2016', '2016', 'abierto'),
(20, 4, 'bhj', '26/01/2016', '2016', 'abierto'),
(21, 4, 'fghcfgh', '26/01/2016', '2016', 'abierto'),
(22, 4, 'fgjh', '26/01/2016', '2016', 'abierto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `privilegy`
--

CREATE TABLE IF NOT EXISTS `privilegy` (
  `IdPrivilegy` int(11) NOT NULL,
  `privilegy` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `privilegy`
--

INSERT INTO `privilegy` (`IdPrivilegy`, `privilegy`) VALUES
(1, 'administrador'),
(2, 'usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rel_user_center`
--

CREATE TABLE IF NOT EXISTS `rel_user_center` (
  `IdRUC` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idCenter` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `rel_user_center`
--

INSERT INTO `rel_user_center` (`IdRUC`, `idUser`, `idCenter`) VALUES
(13, 1, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_account`
--

CREATE TABLE IF NOT EXISTS `user_account` (
  `IdUA` int(11) NOT NULL,
  `idPrivilegy` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `user_account`
--

INSERT INTO `user_account` (`IdUA`, `idPrivilegy`, `user`, `password`) VALUES
(1, 1, 'erleon', '123456');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `validation_assistance`
--

CREATE TABLE IF NOT EXISTS `validation_assistance` (
  `IdValidateAss` int(11) NOT NULL,
  `IdAssistance` int(11) NOT NULL,
  `IdPersonal` int(11) NOT NULL,
  `validation` varchar(20) NOT NULL,
  `observation` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `validation_assistance`
--

INSERT INTO `validation_assistance` (`IdValidateAss`, `IdAssistance`, `IdPersonal`, `validation`, `observation`) VALUES
(9, 86, 1, 'InvÃƒÂ¡lido', 'Por embustero, aquÃ­ no se fue la luz, Ã©l fue quien no vino a trabajar.'),
(10, 87, 1, 'VÃƒÂ¡lido', ''),
(11, 88, 0, 'No validado', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `assistance`
--
ALTER TABLE `assistance`
  ADD PRIMARY KEY (`IdAssistance`),
  ADD KEY `fk_personal` (`IdPersonal`),
  ADD KEY `fk_centers` (`Idcenter`);

--
-- Indices de la tabla `associate_activities`
--
ALTER TABLE `associate_activities`
  ADD PRIMARY KEY (`IdAssociateAct`),
  ADD KEY `fk_id_goal_1` (`IdGoal`);

--
-- Indices de la tabla `associate_challenger`
--
ALTER TABLE `associate_challenger`
  ADD PRIMARY KEY (`IdAssociateCha`),
  ADD KEY `fk_goal` (`IdGoal`),
  ADD KEY `fk_id_challenges` (`IdChallenge`);

--
-- Indices de la tabla `associate_indicators`
--
ALTER TABLE `associate_indicators`
  ADD PRIMARY KEY (`IdAssociateInd`),
  ADD KEY `idx_goal` (`IdGoal`);

--
-- Indices de la tabla `associate_mounths`
--
ALTER TABLE `associate_mounths`
  ADD PRIMARY KEY (`IdassociateMounth`),
  ADD KEY `idx_goal` (`IdGoal`);

--
-- Indices de la tabla `associate_responsibles`
--
ALTER TABLE `associate_responsibles`
  ADD PRIMARY KEY (`IdAssociateResp`),
  ADD UNIQUE KEY `idx_per` (`IdPersonal`),
  ADD KEY `idx_goal` (`IdGoal`);

--
-- Indices de la tabla `centers`
--
ALTER TABLE `centers`
  ADD PRIMARY KEY (`IdCenter`);

--
-- Indices de la tabla `challenges`
--
ALTER TABLE `challenges`
  ADD PRIMARY KEY (`idChallenge`);

--
-- Indices de la tabla `goals`
--
ALTER TABLE `goals`
  ADD PRIMARY KEY (`idGoal`),
  ADD KEY `idPlan` (`idPlan`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`IdPersonal`),
  ADD KEY `fk_center` (`IdCenter`);

--
-- Indices de la tabla `planner`
--
ALTER TABLE `planner`
  ADD PRIMARY KEY (`idPlan`),
  ADD KEY `fk_center` (`idCenter`);

--
-- Indices de la tabla `privilegy`
--
ALTER TABLE `privilegy`
  ADD PRIMARY KEY (`IdPrivilegy`);

--
-- Indices de la tabla `rel_user_center`
--
ALTER TABLE `rel_user_center`
  ADD PRIMARY KEY (`IdRUC`),
  ADD KEY `idUser` (`idUser`),
  ADD KEY `idCenter` (`idCenter`);

--
-- Indices de la tabla `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`IdUA`),
  ADD KEY `fk_provilegy` (`idPrivilegy`);

--
-- Indices de la tabla `validation_assistance`
--
ALTER TABLE `validation_assistance`
  ADD PRIMARY KEY (`IdValidateAss`),
  ADD KEY `fk_validation` (`IdAssistance`),
  ADD KEY `fk_validation1` (`IdPersonal`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `assistance`
--
ALTER TABLE `assistance`
  MODIFY `IdAssistance` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT de la tabla `associate_activities`
--
ALTER TABLE `associate_activities`
  MODIFY `IdAssociateAct` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT de la tabla `associate_challenger`
--
ALTER TABLE `associate_challenger`
  MODIFY `IdAssociateCha` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT de la tabla `associate_indicators`
--
ALTER TABLE `associate_indicators`
  MODIFY `IdAssociateInd` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de la tabla `associate_mounths`
--
ALTER TABLE `associate_mounths`
  MODIFY `IdassociateMounth` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `associate_responsibles`
--
ALTER TABLE `associate_responsibles`
  MODIFY `IdAssociateResp` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT de la tabla `centers`
--
ALTER TABLE `centers`
  MODIFY `IdCenter` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `challenges`
--
ALTER TABLE `challenges`
  MODIFY `idChallenge` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `goals`
--
ALTER TABLE `goals`
  MODIFY `idGoal` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT de la tabla `personal`
--
ALTER TABLE `personal`
  MODIFY `IdPersonal` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `planner`
--
ALTER TABLE `planner`
  MODIFY `idPlan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT de la tabla `privilegy`
--
ALTER TABLE `privilegy`
  MODIFY `IdPrivilegy` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `rel_user_center`
--
ALTER TABLE `rel_user_center`
  MODIFY `IdRUC` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT de la tabla `user_account`
--
ALTER TABLE `user_account`
  MODIFY `IdUA` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `validation_assistance`
--
ALTER TABLE `validation_assistance`
  MODIFY `IdValidateAss` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `assistance`
--
ALTER TABLE `assistance`
  ADD CONSTRAINT `assistance_ibfk_1` FOREIGN KEY (`IdPersonal`) REFERENCES `personal` (`IdPersonal`) ON UPDATE CASCADE,
  ADD CONSTRAINT `assistance_ibfk_2` FOREIGN KEY (`Idcenter`) REFERENCES `centers` (`IdCenter`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `associate_activities`
--
ALTER TABLE `associate_activities`
  ADD CONSTRAINT `fk_goal_1` FOREIGN KEY (`IdGoal`) REFERENCES `goals` (`idGoal`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `associate_challenger`
--
ALTER TABLE `associate_challenger`
  ADD CONSTRAINT `fk_challenges` FOREIGN KEY (`IdChallenge`) REFERENCES `challenges` (`idChallenge`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_goal` FOREIGN KEY (`IdGoal`) REFERENCES `goals` (`idGoal`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `associate_indicators`
--
ALTER TABLE `associate_indicators`
  ADD CONSTRAINT `fk_goal_2` FOREIGN KEY (`IdGoal`) REFERENCES `goals` (`idGoal`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `associate_mounths`
--
ALTER TABLE `associate_mounths`
  ADD CONSTRAINT `fk_goal_3` FOREIGN KEY (`IdGoal`) REFERENCES `goals` (`idGoal`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `associate_responsibles`
--
ALTER TABLE `associate_responsibles`
  ADD CONSTRAINT `fk_goal_4` FOREIGN KEY (`IdGoal`) REFERENCES `goals` (`idGoal`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_personal` FOREIGN KEY (`IdPersonal`) REFERENCES `personal` (`IdPersonal`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `goals`
--
ALTER TABLE `goals`
  ADD CONSTRAINT `fk_id_goal` FOREIGN KEY (`idPlan`) REFERENCES `planner` (`idPlan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `personal`
--
ALTER TABLE `personal`
  ADD CONSTRAINT `fk_centers` FOREIGN KEY (`IdCenter`) REFERENCES `centers` (`IdCenter`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `planner`
--
ALTER TABLE `planner`
  ADD CONSTRAINT `fk_id_centers` FOREIGN KEY (`idCenter`) REFERENCES `centers` (`IdCenter`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `rel_user_center`
--
ALTER TABLE `rel_user_center`
  ADD CONSTRAINT `fk_rel_user_center` FOREIGN KEY (`idUser`) REFERENCES `user_account` (`IdUA`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rel_user_center_1` FOREIGN KEY (`idCenter`) REFERENCES `centers` (`IdCenter`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `user_account`
--
ALTER TABLE `user_account`
  ADD CONSTRAINT `fk_privilegy` FOREIGN KEY (`idPrivilegy`) REFERENCES `privilegy` (`IdPrivilegy`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `validation_assistance`
--
ALTER TABLE `validation_assistance`
  ADD CONSTRAINT `fk_assistance` FOREIGN KEY (`IdAssistance`) REFERENCES `assistance` (`IdAssistance`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
